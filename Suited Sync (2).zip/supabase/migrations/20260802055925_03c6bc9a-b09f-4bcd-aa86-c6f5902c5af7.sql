CREATE TYPE public.item_category AS ENUM ('top','bottom','dress','outerwear','shoes','accessory');
CREATE TYPE public.formality_level AS ENUM ('casual','business_casual','formal','athletic');
CREATE TYPE public.outfit_status AS ENUM ('suggested','worn','skipped');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  display_name text,
  reference_photo_url text,
  calendar_provider text,
  calendar_connected boolean NOT NULL DEFAULT false,
  cooldown_days integer NOT NULL DEFAULT 14,
  mirror_generations_used integer NOT NULL DEFAULT 0,
  mirror_quota integer NOT NULL DEFAULT 25,
  mirror_cycle_start date NOT NULL DEFAULT date_trunc('month', now())::date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own profile" ON public.profiles FOR ALL TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE public.closet_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  photo_url text,
  category public.item_category NOT NULL,
  color text,
  color_hex text,
  formality public.formality_level NOT NULL DEFAULT 'business_casual',
  pattern text,
  brand text,
  notes text,
  tags_confirmed boolean NOT NULL DEFAULT false,
  auto_tagged boolean NOT NULL DEFAULT false,
  last_worn_date date,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.closet_items TO authenticated;
GRANT ALL ON public.closet_items TO service_role;
ALTER TABLE public.closet_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own closet items" ON public.closet_items FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX closet_items_user_idx ON public.closet_items (user_id, category);

CREATE TABLE public.event_type_mappings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  keyword text NOT NULL,
  event_label text NOT NULL,
  formality public.formality_level NOT NULL,
  user_corrected boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, keyword)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.event_type_mappings TO authenticated;
GRANT ALL ON public.event_type_mappings TO service_role;
ALTER TABLE public.event_type_mappings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own mappings" ON public.event_type_mappings FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.daily_outfits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  outfit_date date NOT NULL,
  event_label text NOT NULL DEFAULT 'Regular workday',
  formality public.formality_level NOT NULL DEFAULT 'business_casual',
  item_ids uuid[] NOT NULL DEFAULT '{}',
  status public.outfit_status NOT NULL DEFAULT 'suggested',
  worn_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.daily_outfits TO authenticated;
GRANT ALL ON public.daily_outfits TO service_role;
ALTER TABLE public.daily_outfits ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own outfits" ON public.daily_outfits FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE INDEX daily_outfits_user_date_idx ON public.daily_outfits (user_id, outfit_date);

CREATE TABLE public.ai_mirror_previews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  daily_outfit_id uuid REFERENCES public.daily_outfits ON DELETE SET NULL,
  reference_photo_url text NOT NULL,
  generated_image_url text,
  saved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ai_mirror_previews TO authenticated;
GRANT ALL ON public.ai_mirror_previews TO service_role;
ALTER TABLE public.ai_mirror_previews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own previews" ON public.ai_mirror_previews FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER profiles_touch BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER closet_items_touch BEFORE UPDATE ON public.closet_items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER daily_outfits_touch BEFORE UPDATE ON public.daily_outfits FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();