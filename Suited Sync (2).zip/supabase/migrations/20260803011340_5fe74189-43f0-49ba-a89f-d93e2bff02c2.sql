CREATE TABLE public.mirror_pack_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stripe_session_id text NOT NULL UNIQUE,
  quantity integer NOT NULL DEFAULT 1,
  previews_granted integer NOT NULL DEFAULT 10,
  amount_total integer,
  currency text,
  environment text NOT NULL DEFAULT 'sandbox',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_mirror_pack_purchases_user ON public.mirror_pack_purchases(user_id);

GRANT SELECT ON public.mirror_pack_purchases TO authenticated;
GRANT ALL ON public.mirror_pack_purchases TO service_role;

ALTER TABLE public.mirror_pack_purchases ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own purchases readable" ON public.mirror_pack_purchases
  FOR SELECT TO authenticated USING (auth.uid() = user_id);