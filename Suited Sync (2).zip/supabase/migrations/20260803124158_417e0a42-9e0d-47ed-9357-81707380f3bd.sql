REVOKE ALL ON FUNCTION public.consume_mirror_preview(uuid, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_mirror_preview(uuid, text) TO service_role;

REVOKE ALL ON FUNCTION public.grant_mirror_pack(uuid, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.grant_mirror_pack(uuid, integer) TO service_role;