ALTER TYPE public.item_category ADD VALUE IF NOT EXISTS 'jumpsuit';
ALTER TYPE public.item_category ADD VALUE IF NOT EXISTS 'leggings';
ALTER TYPE public.formality_level ADD VALUE IF NOT EXISTS 'sexy_night_out';
ALTER TYPE public.formality_level ADD VALUE IF NOT EXISTS 'lounge';
ALTER TYPE public.formality_level ADD VALUE IF NOT EXISTS 'lingerie';
ALTER TYPE public.formality_level ADD VALUE IF NOT EXISTS 'happy_hour';
ALTER TYPE public.formality_level ADD VALUE IF NOT EXISTS 'swimming';
ALTER TYPE public.formality_level ADD VALUE IF NOT EXISTS 'travel';