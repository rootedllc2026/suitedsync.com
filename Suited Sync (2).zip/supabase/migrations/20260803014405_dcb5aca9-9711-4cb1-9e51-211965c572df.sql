CREATE TABLE public.subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stripe_subscription_id text NOT NULL UNIQUE,
  stripe_customer_id text NOT NULL,
  product_id text,
  price_id text,
  status text NOT NULL DEFAULT 'active',
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean NOT NULL DEFAULT false,
  environment text NOT NULL DEFAULT 'sandbox',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_subscriptions_user ON public.subscriptions(user_id);
CREATE INDEX idx_subscriptions_stripe ON public.subscriptions(stripe_subscription_id);

GRANT SELECT ON public.subscriptions TO authenticated;
GRANT ALL ON public.subscriptions TO service_role;

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own subscription readable" ON public.subscriptions
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE TRIGGER subscriptions_touch BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.profiles
  ADD COLUMN mirror_pack_balance integer NOT NULL DEFAULT 0,
  ADD COLUMN onboarded boolean NOT NULL DEFAULT false;

CREATE OR REPLACE FUNCTION public.has_active_subscription(p_user uuid, p_env text DEFAULT 'sandbox')
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.subscriptions
    WHERE user_id = p_user
      AND environment = p_env
      AND (
        (status IN ('active', 'trialing', 'past_due')
          AND (current_period_end IS NULL OR current_period_end > now()))
        OR (status = 'canceled' AND current_period_end > now())
      )
  );
$$;

CREATE OR REPLACE FUNCTION public.mirror_entitlement(p_user uuid, p_env text DEFAULT 'sandbox')
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cycle date := (date_trunc('month', now()))::date;
  v_used integer := 0;
  v_balance integer := 0;
  v_pro boolean := public.has_active_subscription(p_user, p_env);
  v_quota integer;
BEGIN
  SELECT CASE WHEN mirror_cycle_start < v_cycle THEN 0 ELSE mirror_generations_used END,
         mirror_pack_balance
    INTO v_used, v_balance
    FROM public.profiles WHERE id = p_user;

  v_quota := CASE WHEN v_pro THEN 25 ELSE 3 END;

  RETURN jsonb_build_object(
    'pro', v_pro,
    'tier', CASE WHEN v_pro THEN 'pro' ELSE 'free' END,
    'monthly_quota', v_quota,
    'used', COALESCE(v_used, 0),
    'pack_balance', COALESCE(v_balance, 0),
    'remaining', GREATEST(v_quota - COALESCE(v_used, 0), 0) + COALESCE(v_balance, 0),
    'cycle_start', v_cycle
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.consume_mirror_preview(p_user uuid, p_env text DEFAULT 'sandbox')
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cycle date := (date_trunc('month', now()))::date;
  v_used integer;
  v_balance integer;
  v_quota integer;
  v_pro boolean := public.has_active_subscription(p_user, p_env);
BEGIN
  SELECT CASE WHEN mirror_cycle_start < v_cycle THEN 0 ELSE mirror_generations_used END,
         mirror_pack_balance
    INTO v_used, v_balance
    FROM public.profiles WHERE id = p_user FOR UPDATE;

  IF v_used IS NULL THEN
    RAISE EXCEPTION 'PROFILE_MISSING';
  END IF;

  v_quota := CASE WHEN v_pro THEN 25 ELSE 3 END;

  IF v_used < v_quota THEN
    v_used := v_used + 1;
  ELSIF v_balance > 0 THEN
    v_balance := v_balance - 1;
  ELSE
    RAISE EXCEPTION 'MIRROR_QUOTA_EXHAUSTED';
  END IF;

  UPDATE public.profiles
     SET mirror_generations_used = v_used,
         mirror_pack_balance = v_balance,
         mirror_cycle_start = v_cycle
   WHERE id = p_user;

  RETURN jsonb_build_object(
    'pro', v_pro,
    'tier', CASE WHEN v_pro THEN 'pro' ELSE 'free' END,
    'monthly_quota', v_quota,
    'used', v_used,
    'pack_balance', v_balance,
    'remaining', GREATEST(v_quota - v_used, 0) + v_balance
  );
END;
$$;

CREATE OR REPLACE FUNCTION public.grant_mirror_pack(p_user uuid, p_previews integer)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_balance integer;
BEGIN
  UPDATE public.profiles
     SET mirror_pack_balance = GREATEST(mirror_pack_balance + p_previews, 0)
   WHERE id = p_user
   RETURNING mirror_pack_balance INTO v_balance;
  RETURN COALESCE(v_balance, 0);
END;
$$;

REVOKE ALL ON FUNCTION public.consume_mirror_preview(uuid, text) FROM anon, authenticated;
REVOKE ALL ON FUNCTION public.grant_mirror_pack(uuid, integer) FROM anon, authenticated;
GRANT EXECUTE ON FUNCTION public.consume_mirror_preview(uuid, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.grant_mirror_pack(uuid, integer) TO service_role;
GRANT EXECUTE ON FUNCTION public.mirror_entitlement(uuid, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_active_subscription(uuid, text) TO authenticated, service_role;