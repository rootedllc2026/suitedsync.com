CREATE OR REPLACE FUNCTION public.mirror_entitlement(p_user uuid, p_env text DEFAULT 'sandbox')
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_cycle date := (date_trunc('month', now()))::date;
  v_used integer := 0;
  v_balance integer := 0;
  v_pro boolean;
  v_quota integer;
BEGIN
  IF auth.uid() IS NOT NULL AND auth.uid() <> p_user THEN
    RAISE EXCEPTION 'FORBIDDEN';
  END IF;

  v_pro := public.has_active_subscription(p_user, p_env);

  SELECT CASE WHEN mirror_cycle_start < v_cycle THEN 0 ELSE mirror_generations_used END,
         mirror_pack_balance
    INTO v_used, v_balance
    FROM public.profiles WHERE id = p_user;

  v_quota := CASE WHEN v_pro THEN 25 ELSE 3 END;

  RETURN jsonb_build_object(
    'pro', v_pro,
    'tier', CASE WHEN v_pro THEN 'pro' ELSE 'free' END,
    'monthly_quota', v_quota,
    'used', COALESCE(v_used, 0),
    'pack_balance', COALESCE(v_balance, 0),
    'remaining', GREATEST(v_quota - COALESCE(v_used, 0), 0) + COALESCE(v_balance, 0),
    'cycle_start', v_cycle
  );
END;
$$;

REVOKE ALL ON FUNCTION public.mirror_entitlement(uuid, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.has_active_subscription(uuid, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.consume_mirror_preview(uuid, text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.grant_mirror_pack(uuid, integer) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

GRANT EXECUTE ON FUNCTION public.mirror_entitlement(uuid, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_active_subscription(uuid, text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.consume_mirror_preview(uuid, text) TO service_role;
GRANT EXECUTE ON FUNCTION public.grant_mirror_pack(uuid, integer) TO service_role;