-- 1. Wardrobe availability (laundry / packed away)
ALTER TABLE public.closet_items
  ADD COLUMN IF NOT EXISTS availability text NOT NULL DEFAULT 'available';
ALTER TABLE public.closet_items
  DROP CONSTRAINT IF EXISTS closet_items_availability_check;
ALTER TABLE public.closet_items
  ADD CONSTRAINT closet_items_availability_check
  CHECK (availability IN ('available','laundry','packed_away'));

-- 2. Multiple reference photos ("pick your model shot")
CREATE TABLE IF NOT EXISTS public.reference_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  storage_path text NOT NULL,
  label text,
  is_primary boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reference_photos TO authenticated;
GRANT ALL ON public.reference_photos TO service_role;
ALTER TABLE public.reference_photos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own reference photos" ON public.reference_photos;
CREATE POLICY "own reference photos" ON public.reference_photos
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP TRIGGER IF EXISTS reference_photos_touch ON public.reference_photos;
CREATE TRIGGER reference_photos_touch BEFORE UPDATE ON public.reference_photos
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE INDEX IF NOT EXISTS reference_photos_user_idx ON public.reference_photos(user_id);

-- Backfill the single existing reference photo per profile.
INSERT INTO public.reference_photos (user_id, storage_path, is_primary)
SELECT id, reference_photo_url, true FROM public.profiles
WHERE reference_photo_url IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM public.reference_photos r WHERE r.user_id = profiles.id);

-- 3. Tag QA loop: what users corrected after auto-tagging
CREATE TABLE IF NOT EXISTS public.tag_corrections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  closet_item_id uuid,
  photo_path text,
  field text NOT NULL,
  ai_value text,
  final_value text,
  provider text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.tag_corrections TO authenticated;
GRANT ALL ON public.tag_corrections TO service_role;
ALTER TABLE public.tag_corrections ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own tag corrections" ON public.tag_corrections;
CREATE POLICY "own tag corrections" ON public.tag_corrections
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert own tag corrections" ON public.tag_corrections;
CREATE POLICY "insert own tag corrections" ON public.tag_corrections
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- 4. Dead-letter record for external API failures
CREATE TABLE IF NOT EXISTS public.integration_failures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  kind text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  error text,
  attempts integer NOT NULL DEFAULT 1,
  resolved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.integration_failures TO authenticated;
GRANT ALL ON public.integration_failures TO service_role;
ALTER TABLE public.integration_failures ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own failures readable" ON public.integration_failures;
CREATE POLICY "own failures readable" ON public.integration_failures
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- 5. Funnel analytics
CREATE TABLE IF NOT EXISTS public.analytics_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  props jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.analytics_events TO authenticated;
GRANT ALL ON public.analytics_events TO service_role;
ALTER TABLE public.analytics_events ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "own analytics readable" ON public.analytics_events;
CREATE POLICY "own analytics readable" ON public.analytics_events
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert own analytics" ON public.analytics_events;
CREATE POLICY "insert own analytics" ON public.analytics_events
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS analytics_events_user_name_idx
  ON public.analytics_events(user_id, name, created_at DESC);

-- 6. Global kill switch + per-user daily cost ceiling
CREATE TABLE IF NOT EXISTS public.app_flags (
  key text PRIMARY KEY,
  enabled boolean NOT NULL DEFAULT true,
  number_value integer,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.app_flags TO service_role;
ALTER TABLE public.app_flags ENABLE ROW LEVEL SECURITY;
INSERT INTO public.app_flags (key, enabled, number_value)
VALUES ('ai_mirror', true, 15)
ON CONFLICT (key) DO NOTHING;

CREATE OR REPLACE FUNCTION public.consume_mirror_preview(p_user uuid, p_env text DEFAULT 'sandbox'::text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_cycle date := (date_trunc('month', now()))::date;
  v_used integer;
  v_balance integer;
  v_quota integer;
  v_pro boolean := public.has_active_subscription(p_user, p_env);
  v_flag record;
  v_today integer;
BEGIN
  SELECT enabled, COALESCE(number_value, 15) AS daily_cap
    INTO v_flag FROM public.app_flags WHERE key = 'ai_mirror';

  IF v_flag IS NOT NULL AND v_flag.enabled = false THEN
    RAISE EXCEPTION 'MIRROR_DISABLED';
  END IF;

  SELECT count(*) INTO v_today
    FROM public.ai_mirror_previews
   WHERE user_id = p_user AND created_at >= date_trunc('day', now());

  IF v_flag IS NOT NULL AND v_today >= v_flag.daily_cap THEN
    RAISE EXCEPTION 'MIRROR_DAILY_CAP';
  END IF;

  SELECT CASE WHEN mirror_cycle_start < v_cycle THEN 0 ELSE mirror_generations_used END,
         mirror_pack_balance
    INTO v_used, v_balance
    FROM public.profiles WHERE id = p_user FOR UPDATE;

  IF v_used IS NULL THEN
    RAISE EXCEPTION 'PROFILE_MISSING';
  END IF;

  v_quota := CASE WHEN v_pro THEN 25 ELSE 3 END;

  IF v_used < v_quota THEN
    v_used := v_used + 1;
  ELSIF v_balance > 0 THEN
    v_balance := v_balance - 1;
  ELSE
    RAISE EXCEPTION 'MIRROR_QUOTA_EXHAUSTED';
  END IF;

  UPDATE public.profiles
     SET mirror_generations_used = v_used,
         mirror_pack_balance = v_balance,
         mirror_cycle_start = v_cycle
   WHERE id = p_user;

  RETURN jsonb_build_object(
    'pro', v_pro,
    'tier', CASE WHEN v_pro THEN 'pro' ELSE 'free' END,
    'monthly_quota', v_quota,
    'used', v_used,
    'pack_balance', v_balance,
    'remaining', GREATEST(v_quota - v_used, 0) + v_balance
  );
END;
$function$;

-- 7. Retention: purge every row belonging to a user (storage handled in app code)
CREATE OR REPLACE FUNCTION public.purge_user_data(p_user uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  DELETE FROM public.portfolio_entries WHERE user_id = p_user;
  DELETE FROM public.ai_mirror_previews WHERE user_id = p_user;
  DELETE FROM public.reference_photos WHERE user_id = p_user;
  DELETE FROM public.daily_outfits WHERE user_id = p_user;
  DELETE FROM public.closet_items WHERE user_id = p_user;
  DELETE FROM public.event_type_mappings WHERE user_id = p_user;
  DELETE FROM public.tag_corrections WHERE user_id = p_user;
  DELETE FROM public.analytics_events WHERE user_id = p_user;
  DELETE FROM public.integration_failures WHERE user_id = p_user;
  UPDATE public.profiles SET reference_photo_url = NULL WHERE id = p_user;
END;
$function$;

REVOKE ALL ON FUNCTION public.purge_user_data(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.purge_user_data(uuid) TO service_role;