CREATE TABLE public.portfolio_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  kind text NOT NULL DEFAULT 'look',
  title text,
  event_label text,
  formality public.formality_level,
  item_ids uuid[] NOT NULL DEFAULT '{}',
  image_bucket text,
  image_path text,
  preview_id uuid REFERENCES public.ai_mirror_previews(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX portfolio_entries_preview_unique ON public.portfolio_entries (preview_id) WHERE preview_id IS NOT NULL;
CREATE INDEX portfolio_entries_user_idx ON public.portfolio_entries (user_id, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.portfolio_entries TO authenticated;
GRANT ALL ON public.portfolio_entries TO service_role;

ALTER TABLE public.portfolio_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage their own portfolio entries"
ON public.portfolio_entries FOR ALL TO authenticated
USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER portfolio_entries_touch_updated_at
BEFORE UPDATE ON public.portfolio_entries
FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();