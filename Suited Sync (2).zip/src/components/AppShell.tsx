import { Link, useRouter } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { useAuth } from "@/lib/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import backdropAsset from "@/assets/lookbook-bw.jpg.asset.json";
import closetAsset from "@/assets/closet-room.jpg.asset.json";

const NAV = [
  { to: "/", label: "Today" },
  { to: "/closet", label: "Closet" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/add", label: "Add items" },
  { to: "/insights", label: "Insights" },
  { to: "/billing", label: "Billing" },
  { to: "/settings", label: "Settings" },
] as const;

export function AppShell({
  children,
  backdrop = false,
}: {
  children: React.ReactNode;
  backdrop?: boolean | "lookbook" | "closet";
}) {
  const { userId, loading } = useAuth();
  const router = useRouter();
  const variant = backdrop === true ? "lookbook" : backdrop || null;

  return (
    <div className="relative min-h-screen bg-background">
      {variant && (
        <div aria-hidden className="pointer-events-none fixed inset-0 z-0">
          <img
            src={variant === "closet" ? closetAsset.url : backdropAsset.url}
            alt=""
            className={
              variant === "closet"
                ? "h-full w-full object-cover opacity-[0.3] contrast-110 saturate-125"
                : "h-full w-full object-cover opacity-[0.22] grayscale contrast-125"
            }
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/85 via-background/80 to-background" />
        </div>
      )}

      <PaymentTestModeBanner />

      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">

        <div className="mx-auto flex max-w-6xl items-center gap-6 px-5 py-4 md:px-8">
          <Link to="/" className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-accent" />
            <span className="font-display text-xl leading-none tracking-tight">Suited Sync</span>
          </Link>

          <nav className="hidden flex-1 items-center gap-6 md:flex">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="text-[0.78rem] uppercase tracking-[0.16em] text-muted-foreground transition-colors hover:text-foreground"
                activeProps={{ className: "text-foreground" }}
                activeOptions={{ exact: item.to === "/" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="ml-auto md:ml-0">
            {loading ? null : userId ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={async () => {
                  await supabase.auth.signOut();
                  router.navigate({ to: "/auth" });
                }}
              >
                Sign out
              </Button>
            ) : (
              <Button variant="accent" size="sm" asChild>
                <Link to="/auth">Sign in</Link>
              </Button>
            )}
          </div>
        </div>

        <nav className="flex gap-5 overflow-x-auto border-t border-border/70 px-5 py-2 md:hidden">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="whitespace-nowrap text-[0.7rem] uppercase tracking-[0.16em] text-muted-foreground"
              activeProps={{ className: "text-foreground" }}
              activeOptions={{ exact: item.to === "/" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>

      <main className="relative z-10 mx-auto max-w-6xl px-5 pb-24 pt-8 md:px-8">{children}</main>
    </div>
  );
}
