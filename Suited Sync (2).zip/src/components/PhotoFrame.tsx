import { cn } from "@/lib/utils";
import { useSignedPhoto, type PhotoBucket } from "@/lib/storage";

type Props = {
  bucket?: PhotoBucket | undefined;
  path?: string | null | undefined;
  alt: string;
  className?: string | undefined;
  fallbackLabel?: string | undefined;
};

/** Renders a private storage photo through a short-lived signed URL. */
export function PhotoFrame({
  bucket = "closet",
  path,
  alt,
  className,
  fallbackLabel = "No photo",
}: Props) {
  const { data: url, isLoading } = useSignedPhoto(bucket, path);

  return (
    <div className={cn("relative overflow-hidden bg-secondary", className)}>
      {url ? (
        <img
          src={url}
          alt={alt}
          loading="lazy"
          className="h-full w-full object-cover animate-fade-up"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center px-3 text-center">
          <span className="text-[0.68rem] uppercase tracking-[0.18em] text-muted-foreground">
            {isLoading && path ? "Loading" : fallbackLabel}
          </span>
        </div>
      )}
    </div>
  );
}
