import { Link } from "@tanstack/react-router";
import { RefreshCw, Check, Wand2 } from "lucide-react";
import { PhotoFrame } from "./PhotoFrame";
import { Button } from "@/components/ui/button";
import { CATEGORY_LABELS, type ClosetItem, type Category } from "@/lib/wardrobe";

type Props = {
  items: ClosetItem[];
  missing: Category[];
  worn?: boolean | undefined;
  onRegenerate?: (() => void) | undefined;
  onMarkWorn?: (() => void) | undefined;
  onPreview?: (() => void) | undefined;
  mirrorEnabled?: boolean | undefined;
  mirrorHint?: string | undefined;
  /** One line explaining why these pieces were chosen. */
  rationale?: string | undefined;
  /** Pieces skipped because they're in the wash or packed away. */
  unavailable?: number | undefined;
};

export function OutfitCard({
  items,
  missing,
  worn,
  onRegenerate,
  onMarkWorn,
  onPreview,
  mirrorEnabled,
  mirrorHint,
  rationale,
  unavailable,
}: Props) {

  return (
    <div className="animate-fade-up">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {items.map((item) => (
          <figure key={item.id} className="space-y-2">
            <PhotoFrame
              path={item.photo_url}
              alt={item.name || CATEGORY_LABELS[item.category]}
              className="aspect-[3/4] rounded-sm"
              fallbackLabel={CATEGORY_LABELS[item.category]}
            />
            <figcaption className="space-y-0.5">
              <p className="text-[0.66rem] uppercase tracking-[0.18em] text-accent">
                {CATEGORY_LABELS[item.category]}
              </p>
              <p className="truncate text-sm">{item.name || "Untitled piece"}</p>
            </figcaption>
          </figure>
        ))}
      </div>

      {rationale && (
        <p className="mt-5 border-l-2 border-accent pl-3 text-sm leading-relaxed text-muted-foreground">
          <span className="text-[0.66rem] uppercase tracking-[0.18em] text-accent">Why this</span>
          <br />
          {rationale}
        </p>
      )}

      {!!unavailable && (
        <p className="mt-3 text-xs text-muted-foreground">
          {unavailable} piece{unavailable === 1 ? "" : "s"} skipped — in the laundry or packed away.
        </p>
      )}

      {missing.length > 0 && (
        <p className="mt-4 text-sm text-muted-foreground">
          Your closet is missing {missing.map((m) => CATEGORY_LABELS[m].toLowerCase()).join(", ")} at
          this dress code — add pieces to complete the look.
        </p>
      )}

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {mirrorEnabled ? (
          <Button variant="accent" onClick={onPreview} disabled={!items.length}>
            <Wand2 className="mr-2 h-4 w-4" /> Preview on Me
          </Button>
        ) : (

          <Button variant="outline" asChild title={mirrorHint}>
            <Link to="/settings">
              <Wand2 className="mr-2 h-4 w-4" /> Enable AI Mirror
            </Link>
          </Button>
        )}
        <Button variant="outline" onClick={onRegenerate}>
          <RefreshCw className="mr-2 h-4 w-4" /> Regenerate
        </Button>
        <Button variant="ghost" onClick={onMarkWorn} disabled={worn || !items.length}>
          <Check className="mr-2 h-4 w-4" /> {worn ? "Worn" : "Mark as worn"}
        </Button>
      </div>
      {mirrorHint && !mirrorEnabled && (
        <p className="mt-2 text-xs text-muted-foreground">{mirrorHint}</p>
      )}
    </div>
  );
}
