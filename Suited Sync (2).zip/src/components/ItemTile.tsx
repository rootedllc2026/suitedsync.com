import { Link } from "@tanstack/react-router";
import { PhotoFrame } from "./PhotoFrame";
import {
  AVAILABILITY_LABELS,
  CATEGORY_LABELS,
  FORMALITY_LABELS,
  availabilityOf,
  type ClosetItem,
} from "@/lib/wardrobe";

type Props = {
  item: ClosetItem;
  selectable?: boolean | undefined;
  selected?: boolean | undefined;
  onToggle?: (() => void) | undefined;
};

export function ItemTile({ item, selectable, selected, onToggle }: Props) {
  const availability = availabilityOf(item);

  const body = (
    <>
      <div className="relative">
        <PhotoFrame
          path={item.photo_url}
          alt={item.name || CATEGORY_LABELS[item.category]}
          className={`aspect-[3/4] rounded-sm transition-transform duration-300 group-hover:scale-[1.01] ${
            availability === "available" ? "" : "opacity-60"
          }`}
          fallbackLabel={CATEGORY_LABELS[item.category]}
        />
        {availability !== "available" && (
          <span className="absolute left-2 top-2 bg-foreground px-2 py-1 text-[0.55rem] uppercase tracking-[0.18em] text-background">
            {AVAILABILITY_LABELS[availability]}
          </span>
        )}
        {selectable && (
          <span
            className={`absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full border text-[0.6rem] ${
              selected
                ? "border-accent bg-accent text-accent-foreground"
                : "border-border bg-background/80"
            }`}
          >
            {selected ? "✓" : ""}
          </span>
        )}
      </div>
      <div className="mt-3 space-y-1">
        <p className="truncate text-sm text-foreground">
          {item.name || CATEGORY_LABELS[item.category]}
        </p>
        <p className="text-[0.68rem] uppercase tracking-[0.16em] text-muted-foreground">
          {FORMALITY_LABELS[item.formality]}
          {item.color ? ` · ${item.color}` : ""}
        </p>
      </div>
    </>
  );

  if (selectable) {
    return (
      <button
        type="button"
        onClick={onToggle}
        className={`group block animate-fade-up text-left ${selected ? "ring-1 ring-accent" : ""}`}
      >
        {body}
      </button>
    );
  }

  return (
    <Link
      to="/closet/$itemId"
      params={{ itemId: item.id }}
      className="group block animate-fade-up"
    >
      {body}
    </Link>
  );
}
