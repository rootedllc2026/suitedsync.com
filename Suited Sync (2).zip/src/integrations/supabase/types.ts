export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      ai_mirror_previews: {
        Row: {
          created_at: string
          daily_outfit_id: string | null
          generated_image_url: string | null
          id: string
          reference_photo_url: string
          saved: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          daily_outfit_id?: string | null
          generated_image_url?: string | null
          id?: string
          reference_photo_url: string
          saved?: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          daily_outfit_id?: string | null
          generated_image_url?: string | null
          id?: string
          reference_photo_url?: string
          saved?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ai_mirror_previews_daily_outfit_id_fkey"
            columns: ["daily_outfit_id"]
            isOneToOne: false
            referencedRelation: "daily_outfits"
            referencedColumns: ["id"]
          },
        ]
      }
      analytics_events: {
        Row: {
          created_at: string
          id: string
          name: string
          props: Json
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          props?: Json
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          props?: Json
          user_id?: string
        }
        Relationships: []
      }
      app_flags: {
        Row: {
          enabled: boolean
          key: string
          number_value: number | null
          updated_at: string
        }
        Insert: {
          enabled?: boolean
          key: string
          number_value?: number | null
          updated_at?: string
        }
        Update: {
          enabled?: boolean
          key?: string
          number_value?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      closet_items: {
        Row: {
          auto_tagged: boolean
          availability: string
          brand: string | null
          category: Database["public"]["Enums"]["item_category"]
          color: string | null
          color_hex: string | null
          created_at: string
          formality: Database["public"]["Enums"]["formality_level"]
          id: string
          last_worn_date: string | null
          name: string
          notes: string | null
          pattern: string | null
          photo_url: string | null
          tags_confirmed: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          auto_tagged?: boolean
          availability?: string
          brand?: string | null
          category: Database["public"]["Enums"]["item_category"]
          color?: string | null
          color_hex?: string | null
          created_at?: string
          formality?: Database["public"]["Enums"]["formality_level"]
          id?: string
          last_worn_date?: string | null
          name?: string
          notes?: string | null
          pattern?: string | null
          photo_url?: string | null
          tags_confirmed?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          auto_tagged?: boolean
          availability?: string
          brand?: string | null
          category?: Database["public"]["Enums"]["item_category"]
          color?: string | null
          color_hex?: string | null
          created_at?: string
          formality?: Database["public"]["Enums"]["formality_level"]
          id?: string
          last_worn_date?: string | null
          name?: string
          notes?: string | null
          pattern?: string | null
          photo_url?: string | null
          tags_confirmed?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      daily_outfits: {
        Row: {
          created_at: string
          event_label: string
          formality: Database["public"]["Enums"]["formality_level"]
          id: string
          item_ids: string[]
          outfit_date: string
          status: Database["public"]["Enums"]["outfit_status"]
          updated_at: string
          user_id: string
          worn_at: string | null
        }
        Insert: {
          created_at?: string
          event_label?: string
          formality?: Database["public"]["Enums"]["formality_level"]
          id?: string
          item_ids?: string[]
          outfit_date: string
          status?: Database["public"]["Enums"]["outfit_status"]
          updated_at?: string
          user_id: string
          worn_at?: string | null
        }
        Update: {
          created_at?: string
          event_label?: string
          formality?: Database["public"]["Enums"]["formality_level"]
          id?: string
          item_ids?: string[]
          outfit_date?: string
          status?: Database["public"]["Enums"]["outfit_status"]
          updated_at?: string
          user_id?: string
          worn_at?: string | null
        }
        Relationships: []
      }
      event_type_mappings: {
        Row: {
          created_at: string
          event_label: string
          formality: Database["public"]["Enums"]["formality_level"]
          id: string
          keyword: string
          user_corrected: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          event_label: string
          formality: Database["public"]["Enums"]["formality_level"]
          id?: string
          keyword: string
          user_corrected?: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          event_label?: string
          formality?: Database["public"]["Enums"]["formality_level"]
          id?: string
          keyword?: string
          user_corrected?: boolean
          user_id?: string
        }
        Relationships: []
      }
      integration_failures: {
        Row: {
          attempts: number
          created_at: string
          error: string | null
          id: string
          kind: string
          payload: Json
          resolved: boolean
          user_id: string | null
        }
        Insert: {
          attempts?: number
          created_at?: string
          error?: string | null
          id?: string
          kind: string
          payload?: Json
          resolved?: boolean
          user_id?: string | null
        }
        Update: {
          attempts?: number
          created_at?: string
          error?: string | null
          id?: string
          kind?: string
          payload?: Json
          resolved?: boolean
          user_id?: string | null
        }
        Relationships: []
      }
      mirror_pack_purchases: {
        Row: {
          amount_total: number | null
          created_at: string
          currency: string | null
          environment: string
          id: string
          previews_granted: number
          quantity: number
          stripe_session_id: string
          user_id: string
        }
        Insert: {
          amount_total?: number | null
          created_at?: string
          currency?: string | null
          environment?: string
          id?: string
          previews_granted?: number
          quantity?: number
          stripe_session_id: string
          user_id: string
        }
        Update: {
          amount_total?: number | null
          created_at?: string
          currency?: string | null
          environment?: string
          id?: string
          previews_granted?: number
          quantity?: number
          stripe_session_id?: string
          user_id?: string
        }
        Relationships: []
      }
      portfolio_entries: {
        Row: {
          created_at: string
          event_label: string | null
          formality: Database["public"]["Enums"]["formality_level"] | null
          id: string
          image_bucket: string | null
          image_path: string | null
          item_ids: string[]
          kind: string
          preview_id: string | null
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          event_label?: string | null
          formality?: Database["public"]["Enums"]["formality_level"] | null
          id?: string
          image_bucket?: string | null
          image_path?: string | null
          item_ids?: string[]
          kind?: string
          preview_id?: string | null
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          event_label?: string | null
          formality?: Database["public"]["Enums"]["formality_level"] | null
          id?: string
          image_bucket?: string | null
          image_path?: string | null
          item_ids?: string[]
          kind?: string
          preview_id?: string | null
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "portfolio_entries_preview_id_fkey"
            columns: ["preview_id"]
            isOneToOne: false
            referencedRelation: "ai_mirror_previews"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          calendar_connected: boolean
          calendar_provider: string | null
          cooldown_days: number
          created_at: string
          display_name: string | null
          id: string
          mirror_cycle_start: string
          mirror_generations_used: number
          mirror_pack_balance: number
          mirror_quota: number
          onboarded: boolean
          reference_photo_url: string | null
          updated_at: string
        }
        Insert: {
          calendar_connected?: boolean
          calendar_provider?: string | null
          cooldown_days?: number
          created_at?: string
          display_name?: string | null
          id: string
          mirror_cycle_start?: string
          mirror_generations_used?: number
          mirror_pack_balance?: number
          mirror_quota?: number
          onboarded?: boolean
          reference_photo_url?: string | null
          updated_at?: string
        }
        Update: {
          calendar_connected?: boolean
          calendar_provider?: string | null
          cooldown_days?: number
          created_at?: string
          display_name?: string | null
          id?: string
          mirror_cycle_start?: string
          mirror_generations_used?: number
          mirror_pack_balance?: number
          mirror_quota?: number
          onboarded?: boolean
          reference_photo_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      reference_photos: {
        Row: {
          created_at: string
          id: string
          is_primary: boolean
          label: string | null
          storage_path: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_primary?: boolean
          label?: string | null
          storage_path: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_primary?: boolean
          label?: string | null
          storage_path?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          cancel_at_period_end: boolean
          created_at: string
          current_period_end: string | null
          current_period_start: string | null
          environment: string
          id: string
          price_id: string | null
          product_id: string | null
          status: string
          stripe_customer_id: string
          stripe_subscription_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          environment?: string
          id?: string
          price_id?: string | null
          product_id?: string | null
          status?: string
          stripe_customer_id: string
          stripe_subscription_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          environment?: string
          id?: string
          price_id?: string | null
          product_id?: string | null
          status?: string
          stripe_customer_id?: string
          stripe_subscription_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      tag_corrections: {
        Row: {
          ai_value: string | null
          closet_item_id: string | null
          created_at: string
          field: string
          final_value: string | null
          id: string
          photo_path: string | null
          provider: string | null
          user_id: string
        }
        Insert: {
          ai_value?: string | null
          closet_item_id?: string | null
          created_at?: string
          field: string
          final_value?: string | null
          id?: string
          photo_path?: string | null
          provider?: string | null
          user_id: string
        }
        Update: {
          ai_value?: string | null
          closet_item_id?: string | null
          created_at?: string
          field?: string
          final_value?: string | null
          id?: string
          photo_path?: string | null
          provider?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      consume_mirror_preview: {
        Args: { p_env?: string; p_user: string }
        Returns: Json
      }
      grant_mirror_pack: {
        Args: { p_previews: number; p_user: string }
        Returns: number
      }
      has_active_subscription: {
        Args: { p_env?: string; p_user: string }
        Returns: boolean
      }
      mirror_entitlement: {
        Args: { p_env?: string; p_user: string }
        Returns: Json
      }
      purge_user_data: { Args: { p_user: string }; Returns: undefined }
    }
    Enums: {
      formality_level:
        | "casual"
        | "business_casual"
        | "formal"
        | "athletic"
        | "sexy_night_out"
        | "lounge"
        | "lingerie"
        | "happy_hour"
        | "swimming"
        | "travel"
      item_category:
        | "top"
        | "bottom"
        | "dress"
        | "outerwear"
        | "shoes"
        | "accessory"
        | "jumpsuit"
        | "leggings"
      outfit_status: "suggested" | "worn" | "skipped"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      formality_level: [
        "casual",
        "business_casual",
        "formal",
        "athletic",
        "sexy_night_out",
        "lounge",
        "lingerie",
        "happy_hour",
        "swimming",
        "travel",
      ],
      item_category: [
        "top",
        "bottom",
        "dress",
        "outerwear",
        "shoes",
        "accessory",
        "jumpsuit",
        "leggings",
      ],
      outfit_status: ["suggested", "worn", "skipped"],
    },
  },
} as const
