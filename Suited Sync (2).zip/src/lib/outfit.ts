import {
  BOTTOM_CATEGORIES,
  CATEGORY_LABELS,
  FORMALITY_LABELS,
  FULL_BODY_CATEGORIES,
  comboKey,
  daysSince,
  formalityDistance,
  isWearable,
  type Category,
  type ClosetItem,
  type Formality,
} from "./wardrobe";


function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Ranks an item for a target dress code: exact formality first, then items that
 * have been resting longest, with a small seeded jitter so "Regenerate" varies.
 */
function score(item: ClosetItem, target: Formality, rand: () => number) {
  const dist = formalityDistance(item.formality, target);
  if (dist > 1) return -1;
  const rest = Math.min(daysSince(item.last_worn_date), 120) / 120;
  return 1 - dist * 0.45 + rest * 0.35 + rand() * 0.3;
}

function pool(
  items: ClosetItem[],
  categories: Category | Category[],
  target: Formality,
  rand: () => number,
) {
  const wanted = Array.isArray(categories) ? categories : [categories];
  return items
    .filter((i) => wanted.includes(i.category))
    .map((i) => ({ item: i, s: score(i, target, rand) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
    .map((x) => x.item);
}


export type OutfitSuggestion = {
  items: ClosetItem[];
  missing: Category[];
  /** One plain-English line explaining why this combination was chosen. */
  rationale: string;
  /** Pieces skipped because they're in the wash or packed away. */
  unavailable: number;
};

export type BuildOptions = {
  /** Combination keys retired by the re-wear cooldown. */
  avoid?: Set<string>;
  seed?: number;
  includeOuterwear?: boolean;
  /** Re-wear window, used only for the rationale copy. */
  cooldownDays?: number;
};

/** Explains the pick: dress-code fit, longest-rested piece, cooldown respected. */
export function explainOutfit(
  chosen: ClosetItem[],
  target: Formality,
  cooldownDays: number,
  avoided: boolean,
) {
  const parts: string[] = [];
  const exact = chosen.filter((i) => i.formality === target).length;
  parts.push(
    exact === chosen.length
      ? `Every piece is tagged ${FORMALITY_LABELS[target].toLowerCase()}`
      : `${exact} of ${chosen.length} pieces match ${FORMALITY_LABELS[target].toLowerCase()} exactly, the rest sit one step away`,
  );

  const rested = chosen
    .map((i) => ({ item: i, days: daysSince(i.last_worn_date) }))
    .sort((a, b) => b.days - a.days)[0];
  if (rested) {
    const name = rested.item.name || CATEGORY_LABELS[rested.item.category].toLowerCase();
    parts.push(
      rested.days === Infinity
        ? `your ${name} hasn't been worn yet`
        : `your ${name} last went out ${rested.days} day${rested.days === 1 ? "" : "s"} ago`,
    );
  }

  if (avoided) parts.push(`nothing repeated from the last ${cooldownDays} days`);
  return `${parts.join(" · ")}.`;
}

/**
 * Builds one complete outfit strictly from owned, tagged, currently wearable items.
 * Returns whatever it could assemble plus the categories it could not fill.
 */
export function buildOutfit(
  items: ClosetItem[],
  target: Formality,
  options: BuildOptions = {},
): OutfitSuggestion {
  const avoid = options.avoid ?? new Set<string>();
  const includeOuterwear = options.includeOuterwear ?? true;
  const cooldownDays = options.cooldownDays ?? 14;

  // Laundry basket and packed-away pieces are never suggested.
  const wearable = items.filter(isWearable);
  const unavailable = items.length - wearable.length;
  const empty: OutfitSuggestion = {
    items: [],
    missing: ["top", "bottom", "shoes"],
    rationale: "",
    unavailable,
  };

  for (let attempt = 0; attempt < 60; attempt++) {
    const rand = mulberry((options.seed ?? 1) * 7919 + attempt * 131);
    const tops = pool(wearable, "top", target, rand);
    const bottoms = pool(wearable, BOTTOM_CATEGORIES, target, rand);
    const dresses = pool(wearable, FULL_BODY_CATEGORIES, target, rand);
    const shoes = pool(wearable, "shoes", target, rand);
    const outerwear = includeOuterwear ? pool(wearable, "outerwear", target, rand) : [];

    const pick = <T,>(list: T[], depth: number) =>
      list.length ? list[Math.min(list.length - 1, Math.floor(rand() * depth))] : undefined;

    const useDress = dresses.length > 0 && (tops.length === 0 || bottoms.length === 0 || rand() < 0.35);


    const chosen: ClosetItem[] = [];
    const missing: Category[] = [];

    if (useDress) {
      const dress = pick(dresses, 3);
      if (dress) chosen.push(dress);
      else missing.push("dress");
    } else {
      const top = pick(tops, 4);
      const bottom = pick(bottoms, 4);
      if (top) chosen.push(top);
      else missing.push("top");
      if (bottom) chosen.push(bottom);
      else missing.push("bottom");
    }

    const shoe = pick(shoes, 3);
    if (shoe) chosen.push(shoe);
    else missing.push("shoes");

    if (includeOuterwear && outerwear.length && rand() < 0.6) {
      const layer = pick(outerwear, 2);
      if (layer) chosen.push(layer);
    }

    if (!chosen.length) return empty;

    const key = comboKey(chosen.map((i) => i.id));
    if (!avoid.has(key) || attempt === 59) {
      return {
        items: chosen,
        missing,
        rationale: explainOutfit(chosen, target, cooldownDays, avoid.size > 0),
        unavailable,
      };
    }
  }

  return empty;
}

/** Combination keys still inside the re-wear cooldown window. */
export function retiredCombos(
  worn: { item_ids: string[]; worn_at: string | null; outfit_date: string }[],
  cooldownDays: number,
) {
  const cutoff = Date.now() - cooldownDays * 86_400_000;
  const set = new Set<string>();
  for (const outfit of worn) {
    const when = new Date(outfit.worn_at ?? `${outfit.outfit_date}T00:00:00`).getTime();
    if (when >= cutoff) set.add(comboKey(outfit.item_ids));
  }
  return set;
}
