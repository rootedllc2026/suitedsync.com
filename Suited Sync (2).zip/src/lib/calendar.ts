import type { Formality } from "./wardrobe";

export type EventGuess = {
  label: string;
  formality: Formality;
  keyword: string | null;
  source: "calendar" | "default" | "manual";
};

/**
 * Seed keyword → event-type → formality map. Users can correct any of these;
 * corrections are stored per user in `event_type_mappings`.
 */
export const DEFAULT_EVENT_MAPPINGS: {
  keyword: string;
  event_label: string;
  formality: Formality;
}[] = [
  { keyword: "board", event_label: "Board meeting", formality: "formal" },
  { keyword: "client", event_label: "Client meeting", formality: "formal" },
  { keyword: "investor", event_label: "Investor meeting", formality: "formal" },
  { keyword: "pitch", event_label: "Pitch", formality: "formal" },
  { keyword: "interview", event_label: "Interview", formality: "formal" },
  { keyword: "presentation", event_label: "Presentation", formality: "formal" },
  { keyword: "keynote", event_label: "Speaking engagement", formality: "formal" },
  { keyword: "gala", event_label: "Evening event", formality: "formal" },
  { keyword: "offsite", event_label: "Offsite", formality: "casual" },
  { keyword: "standup", event_label: "Internal day", formality: "business_casual" },
  { keyword: "stand-up", event_label: "Internal day", formality: "business_casual" },
  { keyword: "1:1", event_label: "Internal day", formality: "business_casual" },
  { keyword: "sync", event_label: "Internal day", formality: "business_casual" },
  { keyword: "review", event_label: "Review day", formality: "business_casual" },
  { keyword: "workshop", event_label: "Workshop", formality: "business_casual" },
  { keyword: "training", event_label: "Training", formality: "business_casual" },
  { keyword: "coffee", event_label: "Coffee catch-up", formality: "casual" },
  { keyword: "lunch", event_label: "Lunch", formality: "casual" },
  { keyword: "happy hour", event_label: "Happy hour", formality: "happy_hour" },
  { keyword: "drinks", event_label: "Happy hour", formality: "happy_hour" },
  { keyword: "date night", event_label: "Night out", formality: "sexy_night_out" },
  { keyword: "night out", event_label: "Night out", formality: "sexy_night_out" },
  { keyword: "party", event_label: "Night out", formality: "sexy_night_out" },
  { keyword: "flight", event_label: "Travel day", formality: "travel" },
  { keyword: "travel", event_label: "Travel day", formality: "travel" },
  { keyword: "airport", event_label: "Travel day", formality: "travel" },
  { keyword: "swim", event_label: "Swimming", formality: "swimming" },
  { keyword: "pool", event_label: "Swimming", formality: "swimming" },
  { keyword: "beach", event_label: "Swimming", formality: "swimming" },
  { keyword: "rest day", event_label: "Lounge day", formality: "lounge" },
  { keyword: "wfh", event_label: "Work from home", formality: "casual" },
  { keyword: "remote", event_label: "Work from home", formality: "casual" },
  { keyword: "gym", event_label: "Workout", formality: "athletic" },
  { keyword: "pilates", event_label: "Workout", formality: "athletic" },
  { keyword: "yoga", event_label: "Workout", formality: "athletic" },
  { keyword: "run", event_label: "Workout", formality: "athletic" },
  { keyword: "training session", event_label: "Workout", formality: "athletic" },
];


export const FALLBACK_EVENT: EventGuess = {
  label: "Regular workday",
  formality: "business_casual",
  keyword: null,
  source: "default",
};

export const WEEKEND_EVENT: EventGuess = {
  label: "Weekend",
  formality: "casual",
  keyword: null,
  source: "default",
};

type Mapping = { keyword: string; event_label: string; formality: Formality };

/**
 * Infers the day's event type from calendar entry titles. The highest-formality
 * match wins, because the day has to be dressed for its most demanding meeting.
 */
export function inferEventType(titles: string[], mappings: Mapping[] = []): EventGuess {
  const table = [...DEFAULT_EVENT_MAPPINGS, ...mappings];
  const rank: Record<Formality, number> = {
    lounge: 0,
    lingerie: 0,
    swimming: 0,
    athletic: 0,
    travel: 1,
    casual: 1,
    business_casual: 2,
    happy_hour: 3,
    formal: 4,
    sexy_night_out: 4,
  };


  let best: EventGuess | null = null;
  for (const title of titles) {
    const haystack = title.toLowerCase();
    for (const map of table) {
      if (!haystack.includes(map.keyword.toLowerCase())) continue;
      const guess: EventGuess = {
        label: map.event_label,
        formality: map.formality,
        keyword: map.keyword,
        source: "calendar",
      };
      if (!best || rank[guess.formality] > rank[best.formality]) best = guess;
    }
  }
  return best ?? FALLBACK_EVENT;
}

export function defaultGuessFor(iso: string): EventGuess {
  const dow = new Date(`${iso}T00:00:00`).getDay();
  return dow === 0 || dow === 6 ? WEEKEND_EVENT : FALLBACK_EVENT;
}
