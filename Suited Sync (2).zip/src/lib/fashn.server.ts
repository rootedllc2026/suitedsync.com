/**
 * FASHN virtual try-on client (server-only).
 * Pay-per-generation: each garment layer is one run.
 */

const BASE = "https://api.fashn.ai/v1";

export type FashnCategory = "tops" | "bottoms" | "one-pieces";

export function fashnCategoryFor(category: string): FashnCategory | null {
  if (category === "top" || category === "outerwear") return "tops";
  if (category === "bottom") return "bottoms";
  if (category === "dress") return "one-pieces";
  return null;
}

async function poll(id: string, key: string) {
  for (let attempt = 0; attempt < 40; attempt++) {
    await new Promise((r) => setTimeout(r, 1500));
    const res = await fetch(`${BASE}/status/${id}`, {
      headers: { Authorization: `Bearer ${key}` },
    });
    if (!res.ok) throw new Error(`FASHN status failed [${res.status}]: ${await res.text()}`);
    const body = (await res.json()) as {
      status: string;
      output?: string[];
      error?: unknown;
    };
    if (body.status === "completed" && body.output?.[0]) return body.output[0];
    if (body.status === "failed" || body.status === "canceled") {
      throw new Error(`FASHN generation failed: ${JSON.stringify(body.error ?? body.status)}`);
    }
  }
  throw new Error("FASHN generation timed out");
}

/** Runs one try-on layer and returns the composited image URL. */
export async function tryOnLayer(args: {
  key: string;
  modelImage: string;
  garmentImage: string;
  category: FashnCategory;
}) {
  const res = await fetch(`${BASE}/run`, {
    method: "POST",
    headers: { Authorization: `Bearer ${args.key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model_name: "tryon-v1.6",
      inputs: {
        model_image: args.modelImage,
        garment_image: args.garmentImage,
        category: args.category,
        mode: "balanced",
      },
    }),
  });
  if (!res.ok) throw new Error(`FASHN run failed [${res.status}]: ${await res.text()}`);
  const body = (await res.json()) as { id?: string; error?: unknown };
  if (!body.id) throw new Error(`FASHN run failed: ${JSON.stringify(body.error)}`);
  return poll(body.id, args.key);
}

export function currentCycleStart() {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1))
    .toISOString()
    .slice(0, 10);
}

/** Which payment environment this deployment bills against. */
export function paymentsEnv(): "sandbox" | "live" {
  return process.env["STRIPE_LIVE_API_KEY"] ? "live" : "sandbox";
}

