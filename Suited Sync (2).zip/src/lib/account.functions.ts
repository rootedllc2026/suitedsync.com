import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Reference-photo & preview lifecycle. Privacy is enforced here, not just
 * promised in Settings: members can wipe every photo and record we hold, and
 * unsaved previews are purged automatically after their retention window.
 */

const RETENTION_DAYS = 30;

/** Deletes every stored file and row for the signed-in member. */
export const deleteMyData = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const userId = context.userId;

    for (const bucket of ["closet", "reference-photos", "mirror-previews"] as const) {
      const { data: files } = await supabaseAdmin.storage.from(bucket).list(userId, { limit: 1000 });
      const paths = (files ?? []).map((f) => `${userId}/${f.name}`);
      if (paths.length) await supabaseAdmin.storage.from(bucket).remove(paths);
    }

    const { error } = await supabaseAdmin.rpc("purge_user_data", { p_user: userId });
    if (error) throw error;

    return { ok: true };
  });

/** Purges the caller's unsaved previews older than the retention window. */
export const purgeOldPreviews = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const cutoff = new Date(Date.now() - RETENTION_DAYS * 86_400_000).toISOString();

    const { data: stale, error } = await supabaseAdmin
      .from("ai_mirror_previews")
      .select("id, generated_image_url")
      .eq("user_id", context.userId)
      .eq("saved", false)
      .lt("created_at", cutoff);
    if (error) throw error;

    const rows = stale ?? [];
    if (!rows.length) return { removed: 0, retentionDays: RETENTION_DAYS };

    // Keep anything a member pinned into their portfolio.
    const { data: kept } = await supabaseAdmin
      .from("portfolio_entries")
      .select("preview_id")
      .eq("user_id", context.userId)
      .in("preview_id", rows.map((r) => r.id));
    const keepIds = new Set((kept ?? []).map((k) => k.preview_id));

    const doomed = rows.filter((r) => !keepIds.has(r.id));
    const paths = doomed.map((r) => r.generated_image_url).filter((p): p is string => !!p);
    if (paths.length) await supabaseAdmin.storage.from("mirror-previews").remove(paths);
    if (doomed.length) {
      await supabaseAdmin
        .from("ai_mirror_previews")
        .delete()
        .in("id", doomed.map((r) => r.id));
    }

    return { removed: doomed.length, retentionDays: RETENTION_DAYS };
  });
