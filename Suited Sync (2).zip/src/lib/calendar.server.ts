const GATEWAY_URL = "https://connector-gateway.lovable.dev/google_calendar/calendar/v3";

export type CalendarEvent = { title: string; date: string; allDay: boolean };

/** Reads events from the connected Google Calendar between two ISO dates (inclusive). */
export async function fetchCalendarEvents(startISO: string, endISO: string): Promise<CalendarEvent[]> {
  const lovableKey = process.env["LOVABLE_API_KEY"];
  const connectionKey = process.env["GOOGLE_CALENDAR_API_KEY"];
  if (!lovableKey || !connectionKey) {
    throw new Error("Calendar is not connected yet.");
  }

  const params = new URLSearchParams({
    timeMin: `${startISO}T00:00:00Z`,
    timeMax: `${endISO}T23:59:59Z`,
    singleEvents: "true",
    orderBy: "startTime",
    maxResults: "250",
  });

  const response = await fetch(`${GATEWAY_URL}/calendars/primary/events?${params.toString()}`, {
    headers: {
      Authorization: `Bearer ${lovableKey}`,
      "X-Connection-Api-Key": connectionKey,
    },
  });

  if (!response.ok) {
    const body = await response.text();
    console.error(`[calendar] gateway request failed [${response.status}]: ${body}`);
    throw new Error(`Could not read your calendar [${response.status}].`);
  }

  const payload = (await response.json()) as {
    items?: { summary?: string; start?: { date?: string; dateTime?: string } }[];
  };

  return (payload.items ?? [])
    .map((item) => {
      const raw = item.start?.date ?? item.start?.dateTime;
      if (!raw) return null;
      return {
        title: item.summary ?? "",
        date: raw.slice(0, 10),
        allDay: !!item.start?.date,
      };
    })
    .filter((e): e is CalendarEvent => !!e && !!e.title);
}
