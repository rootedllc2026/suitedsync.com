import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { defaultGuessFor, inferEventType, type EventGuess } from "./calendar";

const RangeInput = z.object({
  start: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  end: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
});

export type CalendarInference = {
  connected: boolean;
  days: Record<string, EventGuess>;
  titles: Record<string, string[]>;
};

/** Infers each day's event type in a date range from the connected calendar. */
export const inferCalendarWeek = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => RangeInput.parse(input))
  .handler(async ({ data, context }): Promise<CalendarInference> => {
    if (!process.env["GOOGLE_CALENDAR_API_KEY"] || !process.env["LOVABLE_API_KEY"]) {
      return { connected: false, days: {}, titles: {} };
    }

    const { fetchCalendarEvents } = await import("./calendar.server");
    const events = await fetchCalendarEvents(data.start, data.end);

    const { data: mappings } = await context.supabase
      .from("event_type_mappings")
      .select("keyword, event_label, formality")
      .eq("user_id", context.userId);

    const titles: Record<string, string[]> = {};
    for (const event of events) {
      titles[event.date] = [...(titles[event.date] ?? []), event.title];
    }

    const days: Record<string, EventGuess> = {};
    for (const [iso, dayTitles] of Object.entries(titles)) {
      const guess = inferEventType(dayTitles, mappings ?? []);
      days[iso] = guess.source === "calendar" ? guess : defaultGuessFor(iso);
    }

    await context.supabase
      .from("profiles")
      .update({ calendar_connected: true, calendar_provider: "Google Calendar" })
      .eq("id", context.userId);

    return { connected: true, days, titles };
  });

/** Records a user's correction of an inferred event type so future days match it. */
export const correctEventMapping = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        keyword: z.string().min(2).max(120),
        eventLabel: z.string().min(1).max(120),
        formality: z.string().min(1).max(40),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("event_type_mappings").insert({
      user_id: context.userId,
      keyword: data.keyword.toLowerCase(),
      event_label: data.eventLabel,
      formality: data.formality as never,
      user_corrected: true,
    });
    if (error) throw error;
    return { ok: true };
  });
