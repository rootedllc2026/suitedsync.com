import type { ClosetItem, Formality } from "@/lib/wardrobe";

/** Sample wardrobe used by the public /demo route — no database, no auth. */
function item(
  id: string,
  name: string,
  category: ClosetItem["category"],
  formality: Formality,
  color: string,
  colorHex: string,
  lastWornDaysAgo: number | null,
): ClosetItem {
  const lastWorn =
    lastWornDaysAgo === null
      ? null
      : new Date(Date.now() - lastWornDaysAgo * 86_400_000).toISOString().slice(0, 10);
  return {
    id,
    user_id: "demo-user",
    name,
    photo_url: null,
    category,
    color,
    color_hex: colorHex,
    formality,
    pattern: null,
    brand: null,
    notes: null,
    tags_confirmed: true,
    auto_tagged: true,
    last_worn_date: lastWorn,
    availability: "available",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

export const DEMO_ITEMS: ClosetItem[] = [
  item("d1", "Ivory silk blouse", "top", "formal", "Ivory", "#f4efe7", 21),
  item("d2", "Black tailored blazer", "outerwear", "formal", "Black", "#131313", 34),
  item("d3", "Charcoal wide-leg trousers", "bottom", "formal", "Charcoal", "#3a3a3d", 12),
  item("d4", "Crimson pointed pumps", "shoes", "formal", "Red", "#8c1d21", 40),
  item("d5", "Striped poplin shirt", "top", "business_casual", "White", "#ece9e2", 6),
  item("d6", "Stone pencil skirt", "bottom", "business_casual", "Stone", "#b9ab97", 18),
  item("d7", "Knit midi dress", "dress", "business_casual", "Espresso", "#4b3a2f", 27),
  item("d8", "Leather loafers", "shoes", "business_casual", "Cognac", "#8a5a33", 9),
  item("d9", "Cashmere crewneck", "top", "casual", "Oat", "#d8cbb8", 4),
  item("d10", "Straight-leg denim", "bottom", "casual", "Indigo", "#2f3b52", 8),
  item("d11", "White leather sneakers", "shoes", "casual", "White", "#f2f2f0", 2),
  item("d12", "Trench coat", "outerwear", "business_casual", "Camel", "#b08a5c", 45),
  item("d13", "Slip midi dress", "dress", "sexy_night_out", "Black", "#0f0f10", 60),
  item("d14", "Strappy heels", "shoes", "sexy_night_out", "Black", "#111112", 55),
  item("d15", "Performance leggings", "leggings", "athletic", "Black", "#1a1a1c", 3),
  item("d16", "Running trainers", "shoes", "athletic", "Grey", "#7d7d82", 3),
  item("d17", "Ribbed tank", "top", "athletic", "Slate", "#5c6068", 5),
  item("d18", "Linen jumpsuit", "jumpsuit", "casual", "Sand", "#cbb99c", 30),
];

export const DEMO_WEEK: { label: string; formality: Formality }[] = [
  { label: "Client meeting", formality: "formal" },
  { label: "Regular workday", formality: "business_casual" },
  { label: "Work from home", formality: "casual" },
  { label: "Board presentation", formality: "formal" },
  { label: "Happy hour", formality: "happy_hour" },
];
