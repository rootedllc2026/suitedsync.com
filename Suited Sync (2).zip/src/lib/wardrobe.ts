import type { Tables } from "@/integrations/supabase/types";

export type ClosetItem = Tables<"closet_items">;
export type Profile = Tables<"profiles">;
export type DailyOutfit = Tables<"daily_outfits">;
export type MirrorPreview = Tables<"ai_mirror_previews">;

export type Category = ClosetItem["category"];
export type Formality = ClosetItem["formality"];

export const CATEGORIES: Category[] = [
  "top",
  "bottom",
  "leggings",
  "dress",
  "jumpsuit",
  "outerwear",
  "shoes",
  "accessory",
];

export const FORMALITIES: Formality[] = [
  "casual",
  "business_casual",
  "formal",
  "athletic",
  "sexy_night_out",
  "happy_hour",
  "lounge",
  "lingerie",
  "swimming",
  "travel",
];

export const CATEGORY_LABELS: Record<Category, string> = {
  top: "Top",
  bottom: "Bottom",
  leggings: "Leggings",
  dress: "Dress",
  jumpsuit: "Jumpsuit",
  outerwear: "Outerwear",
  shoes: "Shoes",
  accessory: "Accessory",
};

export const FORMALITY_LABELS: Record<Formality, string> = {
  casual: "Casual",
  business_casual: "Business casual",
  formal: "Formal",
  athletic: "Athletic",
  sexy_night_out: "Sexy night out",
  happy_hour: "Happy hour",
  lounge: "Lounge wear",
  lingerie: "Lingerie",
  swimming: "Swimming",
  travel: "Travel ready",
};

/** Whether a piece is wearable right now, in the wash, or stored away. */
export type Availability = "available" | "laundry" | "packed_away";

export const AVAILABILITIES: Availability[] = ["available", "laundry", "packed_away"];

export const AVAILABILITY_LABELS: Record<Availability, string> = {
  available: "In rotation",
  laundry: "In the laundry",
  packed_away: "Packed away",
};

export function availabilityOf(item: ClosetItem): Availability {
  const value = item.availability;
  return (AVAILABILITIES as string[]).includes(value)
    ? (value as Availability)
    : "available";
}

export function isWearable(item: ClosetItem) {
  return availabilityOf(item) === "available";
}

/** Full-body pieces that replace a top + bottom pairing. */
export const FULL_BODY_CATEGORIES: Category[] = ["dress", "jumpsuit"];

/** Categories that can fill the "bottom" slot of an outfit. */
export const BOTTOM_CATEGORIES: Category[] = ["bottom", "leggings"];

/** Ordered dress-code ladder used to score how close an item is to a day's needs. */
export const FORMALITY_LADDER: Formality[] = ["athletic", "casual", "business_casual", "formal"];

/**
 * Occasion-specific dress codes that sit outside the office ladder — they only
 * ever substitute for themselves (plus a couple of natural neighbours).
 */
const OCCASION_NEIGHBOURS: Partial<Record<Formality, Formality[]>> = {
  sexy_night_out: ["happy_hour"],
  happy_hour: ["sexy_night_out", "business_casual", "casual"],
  travel: ["casual", "lounge"],
  lounge: ["travel", "casual"],
  swimming: [],
  lingerie: [],
};

export function formalityDistance(a: Formality, b: Formality) {
  if (a === b) return 0;
  const aLadder = FORMALITY_LADDER.includes(a) && !(a in OCCASION_NEIGHBOURS);
  const bLadder = FORMALITY_LADDER.includes(b) && !(b in OCCASION_NEIGHBOURS);
  if (!aLadder || !bLadder) {
    if (OCCASION_NEIGHBOURS[a]?.includes(b) || OCCASION_NEIGHBOURS[b]?.includes(a)) return 1;
    return 99;
  }
  // Athletic never substitutes for office wear and vice versa.
  if ((a === "athletic") !== (b === "athletic")) return 99;
  return Math.abs(FORMALITY_LADDER.indexOf(a) - FORMALITY_LADDER.indexOf(b));
}


export function daysSince(date: string | null) {
  if (!date) return Infinity;
  const ms = Date.now() - new Date(`${date}T00:00:00`).getTime();
  return Math.floor(ms / 86_400_000);
}

export function comboKey(ids: string[]) {
  return [...ids].sort().join("|");
}

export function todayISO() {
  return new Date().toLocaleDateString("en-CA");
}

export function isoForOffset(offset: number) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toLocaleDateString("en-CA");
}

export function prettyDate(iso: string) {
  return new Date(`${iso}T00:00:00`).toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });
}

export function shortDay(iso: string) {
  return new Date(`${iso}T00:00:00`).toLocaleDateString(undefined, { weekday: "short" });
}

/** Monday-anchored weekday strip (Mon–Fri) for the week containing `iso`. */
export function weekdaysOf(iso: string) {
  const d = new Date(`${iso}T00:00:00`);
  const dow = (d.getDay() + 6) % 7;
  const monday = new Date(d);
  monday.setDate(d.getDate() - dow);
  return Array.from({ length: 5 }, (_, i) => {
    const day = new Date(monday);
    day.setDate(monday.getDate() + i);
    return day.toLocaleDateString("en-CA");
  });
}
