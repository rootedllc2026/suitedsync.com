import { mapCategory, mapFormality, mapPattern } from "./taxonomy";
import type { Category, Formality } from "./wardrobe";

export type VisionTags = {
  category: Category;
  formality: Formality;
  color: string | null;
  colorHex: string | null;
  pattern: string | null;
  name: string;
};

const CATEGORIES = [
  "top",
  "bottom",
  "leggings",
  "dress",
  "jumpsuit",
  "outerwear",
  "shoes",
  "accessory",
];
const FORMALITIES = [
  "casual",
  "business_casual",
  "formal",
  "athletic",
  "sexy_night_out",
  "happy_hour",
  "lounge",
  "lingerie",
  "swimming",
  "travel",
];


const SCHEMA = {
  type: "object",
  additionalProperties: false,
  properties: {
    garment_found: { type: "boolean" },
    category: { type: "string", enum: CATEGORIES },
    formality: { type: "string", enum: FORMALITIES },
    color_name: { type: "string" },
    color_hex: { type: "string" },
    pattern: { type: "string" },
    name: { type: "string" },
    descriptors: { type: "array", items: { type: "string" } },
  },
  required: [
    "garment_found",
    "category",
    "formality",
    "color_name",
    "color_hex",
    "pattern",
    "name",
    "descriptors",
  ],
} as const;

const SYSTEM = `You are a fashion cataloguer tagging a single clothing item for a working professional woman's digital closet.
Photos are real closet photos: garments may be hung on a hanger, folded flat, laid on a bed, or worn. Ignore the background, the hanger, the person's face, and any other garment that is clearly not the subject.
Tag ONLY the single main garment.
- category: one of ${CATEGORIES.join(", ")}. Blazers/coats/jackets are outerwear. Jumpsuits, rompers and playsuits are jumpsuit. Leggings, tights and yoga pants are leggings. Bags/belts/scarves/jewellery are accessory.
- formality: one of ${FORMALITIES.join(", ")} — pick the occasion the item is really for. Suiting, tailored, silk, sheath = formal. Blouses, knitwear, trousers, loafers = business_casual. Denim, tees, sandals = casual. Sportswear, sneakers = athletic. Sequins, bodycon, mini/slip dresses, stilettos = sexy_night_out. Dressier-but-relaxed going-out pieces = happy_hour. Pyjamas, robes, sweats, slippers = lounge. Bras, briefs, chemises, lace sets = lingerie. Swimsuits, bikinis, cover-ups = swimming. Wrinkle-free, packable, comfortable travel pieces = travel.

- color_name: the dominant colour in plain English (e.g. "Charcoal", "Cream", "Navy").
- color_hex: that colour as a #rrggbb hex sampled from the fabric.
- pattern: "Solid", "Striped", "Plaid", "Floral", "Polka dot", "Animal", "Tweed", "Geometric" or "" if unclear.
- name: a short 2-4 word retail-style name, e.g. "Ivory silk blouse".
- descriptors: 3-8 lowercase keywords about fabric, cut and styling (e.g. "tailored", "wool", "pencil").
If the image contains no clothing item at all, set garment_found to false and leave the other fields as best guesses.`;

/**
 * Tags a closet photo using Lovable AI vision. Returns null when the model
 * could not identify a garment, so callers can fall back to manual tagging.
 */
export async function tagPhotoWithVision(
  imageUrl: string,
  apiKey: string,
): Promise<VisionTags | null> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Lovable-API-Key": apiKey,
    },
    body: JSON.stringify({
      model: "google/gemini-3.5-flash",
      messages: [
        { role: "system", content: SYSTEM },
        {
          role: "user",
          content: [
            { type: "text", text: "Tag this closet item." },
            { type: "image_url", image_url: { url: imageUrl } },
          ],
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: { name: "closet_item_tags", strict: true, schema: SCHEMA },
      },
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    const err = new Error(`ai_gateway_${res.status}: ${body.slice(0, 400)}`);
    (err as Error & { status?: number }).status = res.status;
    throw err;
  }

  const payload = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const content = payload.choices?.[0]?.message?.content;
  if (!content) return null;

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(content) as Record<string, unknown>;
  } catch {
    return null;
  }

  if (parsed["garment_found"] === false) return null;

  const str = (key: string) =>
    typeof parsed[key] === "string" ? (parsed[key] as string).trim() : "";
  const descriptors = Array.isArray(parsed["descriptors"])
    ? (parsed["descriptors"] as unknown[]).map((d) => String(d).toLowerCase())
    : [];

  const rawCategory = str("category").toLowerCase();
  const category = (
    CATEGORIES.includes(rawCategory)
      ? rawCategory
      : mapCategory([...descriptors, str("name").toLowerCase()])
  ) as Category;

  const rawFormality = str("formality").toLowerCase();
  const formality = (
    FORMALITIES.includes(rawFormality)
      ? rawFormality
      : mapFormality([...descriptors, str("name").toLowerCase()], category)
  ) as Formality;

  const hex = str("color_hex");
  const normalisedHex = /^#?[0-9a-fA-F]{6}$/.test(hex)
    ? hex.startsWith("#")
      ? hex
      : `#${hex}`
    : null;

  const pattern =
    str("pattern") || mapPattern([...descriptors, str("name").toLowerCase()]) || null;

  return {
    category,
    formality,
    color: str("color_name") || null,
    colorHex: normalisedHex,
    pattern,
    name: str("name").slice(0, 60),
  };
}
