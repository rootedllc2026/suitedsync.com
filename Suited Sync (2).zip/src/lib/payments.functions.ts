import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({
  priceId: z.string().regex(/^[a-zA-Z0-9_-]+$/),
  quantity: z.number().int().min(1).max(5).optional(),
  returnUrl: z.string().url(),
  environment: z.enum(["sandbox", "live"]),
});

const PortalInput = z.object({
  returnUrl: z.string().url().optional(),
  environment: z.enum(["sandbox", "live"]),
});

type CheckoutResult = { clientSecret: string } | { error: string };
type PortalResult = { url: string } | { error: string };

/** Creates an embedded checkout session for the signed-in user. */
export const createCheckoutSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data, context }): Promise<CheckoutResult> => {
    const { createStripeClient, getStripeErrorMessage } = await import("@/lib/stripe.server");
    try {
      const stripe = createStripeClient(data.environment);
      const {
        data: { user },
      } = await context.supabase.auth.getUser();

      const prices = await stripe.prices.list({ lookup_keys: [data.priceId] });
      const stripePrice = prices.data[0];
      if (!stripePrice) throw new Error("Price not found");

      const userId = context.userId;
      const isRecurring = !!stripePrice.recurring;

      // A member may hold only one active Pro subscription at a time.
      if (isRecurring) {
        const { data: active } = await context.supabase
          .from("subscriptions")
          .select("status, current_period_end")
          .eq("user_id", userId)
          .eq("environment", data.environment)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        const stillValid =
          active &&
          ["active", "trialing", "past_due"].includes(active.status) &&
          (!active.current_period_end || new Date(active.current_period_end) > new Date());
        if (stillValid) {
          return { error: "You already have an active Pro membership." };
        }
      }

      let customerId: string | undefined;
      const found = await stripe.customers.search({
        query: `metadata['userId']:'${userId}'`,
        limit: 1,
      });
      if (found.data[0]) {
        customerId = found.data[0].id;
      } else if (user?.email) {
        const existing = await stripe.customers.list({ email: user.email, limit: 1 });
        const match = existing.data[0];
        if (match) {
          customerId = match.id;
          if (match.metadata?.["userId"] !== userId) {
            await stripe.customers.update(match.id, {
              metadata: { ...match.metadata, userId },
            });
          }
        }
      }
      if (!customerId) {
        const created = await stripe.customers.create({
          ...(user?.email ? { email: user.email } : {}),
          metadata: { userId },
        });
        customerId = created.id;
      }

      const productId =
        typeof stripePrice.product === "string" ? stripePrice.product : stripePrice.product.id;
      const product = await stripe.products.retrieve(productId);

      const session = await stripe.checkout.sessions.create({
        line_items: [{ price: stripePrice.id, quantity: data.quantity ?? 1 }],
        mode: isRecurring ? "subscription" : "payment",
        ui_mode: "embedded_page",
        return_url: data.returnUrl,
        customer: customerId,
        metadata: { userId, priceId: data.priceId, managed_payments: "true" },
        managed_payments: { enabled: true },
        ...(isRecurring
          ? { subscription_data: { metadata: { userId, priceId: data.priceId } } }
          : { payment_intent_data: { description: product.name } }),
      } as never);

      return { clientSecret: session.client_secret ?? "" };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });

/** Opens the Stripe billing portal so the member can manage or cancel their plan. */
export const createPortalSession = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => PortalInput.parse(input))
  .handler(async ({ data, context }): Promise<PortalResult> => {
    const { createStripeClient, getStripeErrorMessage } = await import("@/lib/stripe.server");
    try {
      const { data: sub } = await context.supabase
        .from("subscriptions")
        .select("stripe_customer_id")
        .eq("user_id", context.userId)
        .eq("environment", data.environment)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (!sub?.stripe_customer_id) {
        return { error: "No billing account yet — start a membership first." };
      }

      const stripe = createStripeClient(data.environment);
      const portal = await stripe.billingPortal.sessions.create({
        customer: sub.stripe_customer_id,
        ...(data.returnUrl ? { return_url: data.returnUrl } : {}),
      });
      return { url: portal.url };
    } catch (error) {
      return { error: getStripeErrorMessage(error) };
    }
  });
