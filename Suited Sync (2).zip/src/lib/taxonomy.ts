import type { Category, Formality } from "./wardrobe";

/**
 * Local taxonomy bridge. Fashion tagging APIs return rich garment taxonomies but
 * no "formality" field, so we map their category/feature vocabulary onto our
 * custom formality levels here.
 */

const CATEGORY_RULES: { category: Category; keywords: string[] }[] = [
  {
    category: "shoes",
    keywords: [
      "footwear",
      "shoe",
      "boot",
      "heel",
      "pump",
      "loafer",
      "sneaker",
      "sandal",
      "flat",
      "mule",
      "trainer",
    ],
  },
  {
    category: "outerwear",
    keywords: [
      "outerwear",
      "coat",
      "trench",
      "blazer",
      "jacket",
      "parka",
      "overcoat",
      "cardigan",
      "vest",
    ],
  },
  {
    category: "jumpsuit",
    keywords: ["jumpsuit", "romper", "playsuit", "boilersuit", "overall", "catsuit"],
  },
  {
    category: "dress",
    keywords: ["dress", "gown", "one-piece", "swimsuit", "bikini", "kaftan"],
  },
  {
    category: "leggings",
    keywords: ["legging", "tights", "yoga pant", "jegging", "bike short"],
  },
  {
    category: "bottom",
    keywords: [
      "bottom",
      "trouser",
      "pant",
      "jean",
      "skirt",
      "short",
      "chino",
      "culotte",
      "slacks",
    ],
  },

  {
    category: "top",
    keywords: [
      "top",
      "shirt",
      "blouse",
      "tee",
      "t-shirt",
      "knit",
      "sweater",
      "jumper",
      "camisole",
      "tank",
      "turtleneck",
      "bodysuit",
      "pullover",
      "hoodie",
    ],
  },
  {
    category: "accessory",
    keywords: [
      "accessor",
      "bag",
      "belt",
      "scarf",
      "hat",
      "jewel",
      "necklace",
      "earring",
      "watch",
      "sunglass",
      "handbag",
    ],
  },
];

const FORMAL_HINTS = [
  "suit",
  "tailored",
  "blazer",
  "gown",
  "silk",
  "satin",
  "pencil",
  "sheath",
  "dress shirt",
  "oxford",
  "pump",
  "heel",
  "trench",
  "wool",
  "pinstripe",
  "tuxedo",
  "formal",
  "evening",
];

const BUSINESS_CASUAL_HINTS = [
  "blouse",
  "knit",
  "cardigan",
  "midi",
  "trouser",
  "chino",
  "loafer",
  "shirt",
  "sweater",
  "pleated",
  "ankle",
  "mule",
  "smart",
  "office",
  "shirtdress",
];

const ATHLETIC_HINTS = [
  "sport",
  "athletic",
  "active",
  "legging",
  "jogger",
  "sweatpant",
  "tracksuit",
  "gym",
  "yoga",
  "running",
  "sneaker",
  "trainer",
  "hoodie",
  "performance",
];

const CASUAL_HINTS = [
  "jean",
  "denim",
  "t-shirt",
  "tee",
  "tank",
  "short",
  "flip",
  "sandal",
  "casual",
  "graphic",
  "sweatshirt",
  "linen shorts",
];

const SEXY_NIGHT_OUT_HINTS = [
  "sequin",
  "bodycon",
  "mini dress",
  "slip dress",
  "cocktail",
  "party",
  "club",
  "corset",
  "backless",
  "stiletto",
  "mesh",
  "cut-out",
  "cutout",
  "metallic",
  "night out",
];

const HAPPY_HOUR_HINTS = [
  "wrap dress",
  "silk top",
  "blouse dress",
  "kitten heel",
  "block heel",
  "midi dress",
  "going out top",
  "happy hour",
  "drinks",
];

const LOUNGE_HINTS = [
  "lounge",
  "pyjama",
  "pajama",
  "robe",
  "sleep",
  "fleece",
  "slipper",
  "terry",
  "jersey set",
  "loungewear",
];

const LINGERIE_HINTS = [
  "lingerie",
  "bra",
  "bralette",
  "underwear",
  "panty",
  "panties",
  "thong",
  "babydoll",
  "chemise",
  "garter",
  "lace set",
];

const SWIMMING_HINTS = [
  "swim",
  "swimsuit",
  "swimwear",
  "bikini",
  "one-piece swim",
  "trunks",
  "board short",
  "cover-up",
  "kaftan",
  "rash guard",
];

const TRAVEL_HINTS = [
  "travel",
  "airport",
  "wrinkle-free",
  "packable",
  "commuter",
  "wide-leg knit",
  "matching set",
  "comfort stretch",
  "slip-on",
];

const PATTERN_HINTS = [
  "striped",
  "stripe",
  "plaid",
  "check",
  "floral",
  "polka",
  "dot",
  "animal",
  "leopard",
  "houndstooth",
  "geometric",
  "paisley",
  "solid",
  "printed",
  "herringbone",
  "tweed",
];

function hits(tags: string[], list: string[]) {
  return tags.reduce((n, tag) => n + (list.some((k) => tag.includes(k)) ? 1 : 0), 0);
}

export function mapCategory(tags: string[]): Category {
  for (const rule of CATEGORY_RULES) {
    if (tags.some((t) => rule.keywords.some((k) => t.includes(k)))) return rule.category;
  }
  return "top";
}

export function mapFormality(tags: string[], category: Category): Formality {
  const scores: Record<Formality, number> = {
    formal: hits(tags, FORMAL_HINTS) * 1.2,
    business_casual: hits(tags, BUSINESS_CASUAL_HINTS),
    casual: hits(tags, CASUAL_HINTS),
    athletic: hits(tags, ATHLETIC_HINTS) * 1.3,
    sexy_night_out: hits(tags, SEXY_NIGHT_OUT_HINTS) * 1.4,
    happy_hour: hits(tags, HAPPY_HOUR_HINTS) * 1.2,
    lounge: hits(tags, LOUNGE_HINTS) * 1.5,
    lingerie: hits(tags, LINGERIE_HINTS) * 1.8,
    swimming: hits(tags, SWIMMING_HINTS) * 1.8,
    travel: hits(tags, TRAVEL_HINTS) * 1.1,
  };

  const best = (Object.entries(scores) as [Formality, number][]).sort((a, b) => b[1] - a[1])[0];
  if (!best || best[1] === 0) return category === "accessory" ? "business_casual" : "business_casual";
  return best[0];
}

export function mapPattern(tags: string[]): string | null {
  const found = tags.find((t) => PATTERN_HINTS.some((p) => t.includes(p)));
  if (!found) return null;
  return found.charAt(0).toUpperCase() + found.slice(1);
}
