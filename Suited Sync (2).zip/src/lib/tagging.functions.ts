import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Category, Formality } from "./wardrobe";

const Input = z.object({ photoPath: z.string().min(1) });

export type AutoTagResult = {
  category: Category;
  formality: Formality;
  color: string | null;
  colorHex: string | null;
  pattern: string | null;
  name: string;
  provider: "lovable-ai" | "none";
  note?: string;
};

/**
 * Auto-tags a freshly uploaded closet photo with Lovable AI vision, then bridges
 * the result onto our category / color / formality fields. Degrades to empty
 * tags (manual review) whenever the model or gateway can't help.
 */
export const autoTagItem = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data, context }): Promise<AutoTagResult> => {
    const fallback: AutoTagResult = {
      category: "top",
      formality: "business_casual",
      color: null,
      colorHex: null,
      pattern: null,
      name: "",
      provider: "none",
    };

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) {
      return { ...fallback, note: "Auto-tagging is not connected yet — add tags below." };
    }

    const { data: signed, error: signError } = await context.supabase.storage
      .from("closet")
      .createSignedUrl(data.photoPath, 900);
    if (signError || !signed?.signedUrl) {
      return { ...fallback, note: "Could not read the photo for tagging." };
    }

    const { tagPhotoWithVision } = await import("./tagging.server");
    const { withRetry, recordFailure } = await import("./resilience.server");

    try {
      const tags = await withRetry(() => tagPhotoWithVision(signed.signedUrl, apiKey), {
        label: "auto-tag",
        attempts: 3,
      });
      if (!tags) {
        return { ...fallback, note: "No garment recognised in this photo — tag it manually." };
      }
      return { ...tags, provider: "lovable-ai" };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`[auto-tag] ${message}`);
      await recordFailure({
        userId: context.userId,
        kind: "auto_tag",
        payload: { photoPath: data.photoPath },
        error,
        attempts: 3,
      });
      const status = (error as { status?: number }).status;
      if (status === 429) {
        return { ...fallback, note: "Auto-tagging is busy right now — try again in a moment." };
      }
      if (status === 402) {
        return { ...fallback, note: "AI credits are exhausted — tag manually or top up credits." };
      }
      return { ...fallback, note: "Auto-tagging failed — tag it manually below." };
    }
  });
