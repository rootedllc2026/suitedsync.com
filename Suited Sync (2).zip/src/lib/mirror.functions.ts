import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const Input = z.object({
  outfitId: z.string().uuid().nullable().optional(),
  /** Which model shot to render on. Falls back to the profile's primary photo. */
  referencePath: z.string().min(1).nullable().optional(),
  garments: z
    .array(z.object({ path: z.string().min(1), category: z.string().min(1) }))
    .min(1)
    .max(4),
});

export type MirrorResult = {
  previewId: string;
  imagePath: string;
  entitlement: Entitlement;
};

export type Entitlement = {
  pro: boolean;
  tier: "free" | "pro";
  monthly_quota: number;
  used: number;
  pack_balance: number;
  remaining: number;
};

/** Reads the caller's AI Mirror entitlement (plan allowance + purchased packs). */
export const getMirrorUsage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { paymentsEnv } = await import("./fashn.server");
    const { mirrorFlag } = await import("./resilience.server");
    const { data, error } = await context.supabase.rpc("mirror_entitlement", {
      p_user: context.userId,
      p_env: paymentsEnv(),
    });
    if (error) throw error;

    const { data: profile } = await context.supabase
      .from("profiles")
      .select("reference_photo_url")
      .eq("id", context.userId)
      .maybeSingle();

    const { count } = await context.supabase
      .from("reference_photos")
      .select("id", { count: "exact", head: true });

    const flag = await mirrorFlag();
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const { count: today } = await context.supabase
      .from("ai_mirror_previews")
      .select("id", { count: "exact", head: true })
      .gte("created_at", startOfDay.toISOString());

    return {
      ...(data as unknown as Entitlement),
      hasReference: !!profile?.reference_photo_url || (count ?? 0) > 0,
      referenceCount: count ?? 0,
      configured: !!process.env["FASHN_API_KEY"],
      serviceEnabled: flag.enabled,
      dailyCap: flag.dailyCap,
      dailyRemaining: Math.max(flag.dailyCap - (today ?? 0), 0),
    };
  });

/** Generates a virtual try-on composite of the caller wearing a suggested outfit. */
export const generateMirrorPreview = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => Input.parse(input))
  .handler(async ({ data, context }): Promise<MirrorResult> => {
    const { tryOnLayer, fashnCategoryFor, paymentsEnv } = await import("./fashn.server");
    const { withRetry, recordFailure, mirrorFlag } = await import("./resilience.server");

    const key = process.env["FASHN_API_KEY"];
    if (!key) throw new Error("AI Mirror is not connected yet. Add the FASHN API key in settings.");

    // Global kill switch — checked before any billable work happens.
    const flag = await mirrorFlag();
    if (!flag.enabled) {
      throw new Error("AI Mirror is paused for maintenance right now. Please try again later.");
    }

    const { data: profile, error: profileError } = await context.supabase
      .from("profiles")
      .select("reference_photo_url")
      .eq("id", context.userId)
      .maybeSingle();
    if (profileError) throw profileError;

    let referencePath = profile?.reference_photo_url ?? null;
    if (data.referencePath) {
      // Only accept a path the caller actually owns.
      const { data: owned } = await context.supabase
        .from("reference_photos")
        .select("storage_path")
        .eq("storage_path", data.referencePath)
        .maybeSingle();
      if (!owned) throw new Error("That reference photo is no longer available.");
      referencePath = owned.storage_path;
    }
    if (!referencePath) {
      throw new Error("Add a full-body reference photo in Settings to use AI Mirror.");
    }

    const layers = data.garments
      .map((g) => ({ ...g, fashn: fashnCategoryFor(g.category) }))
      .filter((g) => g.fashn)
      .sort(
        (a, b) =>
          (a.fashn === "tops" || a.fashn === "one-pieces" ? -1 : 1) -
          (b.fashn === "tops" || b.fashn === "one-pieces" ? -1 : 1),
      );

    if (!layers.length) throw new Error("This outfit has no wearable garment photos to preview.");

    // Reserve the credit atomically before spending money at FASHN. The RPC also
    // enforces the per-user daily generation ceiling.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: consumed, error: consumeError } = await supabaseAdmin.rpc(
      "consume_mirror_preview",
      { p_user: context.userId, p_env: paymentsEnv() },
    );
    if (consumeError) {
      if (consumeError.message.includes("MIRROR_QUOTA_EXHAUSTED")) {
        throw new Error(
          "You're out of AI Mirror previews. Upgrade to Pro or add an extra pack to keep going.",
        );
      }
      if (consumeError.message.includes("MIRROR_DAILY_CAP")) {
        throw new Error(
          `You've hit today's safety limit of ${flag.dailyCap} previews. It resets at midnight.`,
        );
      }
      if (consumeError.message.includes("MIRROR_DISABLED")) {
        throw new Error("AI Mirror is paused for maintenance right now. Please try again later.");
      }
      throw consumeError;
    }
    const entitlement = consumed as unknown as Entitlement;

    const refund = async () => {
      await supabaseAdmin.rpc("grant_mirror_pack", { p_user: context.userId, p_previews: 1 });
    };

    try {
      const signed = async (bucket: string, path: string) => {
        const { data: url, error } = await context.supabase.storage
          .from(bucket)
          .createSignedUrl(path, 1800);
        if (error || !url?.signedUrl) throw new Error("Could not read one of the photos.");
        return url.signedUrl;
      };

      let modelImage = await signed("reference-photos", referencePath);

      for (const layer of layers) {
        const garmentImage = await signed("closet", layer.path);
        modelImage = await withRetry(
          () =>
            tryOnLayer({
              key,
              modelImage,
              garmentImage,
              category: layer.fashn!,
            }),
          { label: "fashn-tryon", attempts: 2, baseMs: 1500 },
        );
      }

      const image = await fetch(modelImage);
      if (!image.ok) throw new Error("Could not download the generated preview.");
      const bytes = new Uint8Array(await image.arrayBuffer());
      const imagePath = `${context.userId}/${crypto.randomUUID()}.png`;

      const { error: uploadError } = await context.supabase.storage
        .from("mirror-previews")
        .upload(imagePath, bytes, { contentType: "image/png" });
      if (uploadError) throw uploadError;

      const { data: preview, error: insertError } = await context.supabase
        .from("ai_mirror_previews")
        .insert({
          user_id: context.userId,
          daily_outfit_id: data.outfitId ?? null,
          reference_photo_url: referencePath,
          generated_image_url: imagePath,
        })
        .select("id")
        .single();
      if (insertError) throw insertError;

      return { previewId: preview.id, imagePath, entitlement };
    } catch (error) {
      // Generation failed — hand the credit back so nobody pays for nothing,
      // and keep a dead-letter record of what went wrong.
      await refund();
      await recordFailure({
        userId: context.userId,
        kind: "mirror_preview",
        payload: {
          outfitId: data.outfitId ?? null,
          garments: layers.map((l) => l.path),
          referencePath,
        },
        error,
        attempts: 2,
      });
      throw error;
    }
  });

// Extra preview packs are granted only by the verified payments webhook
// (src/routes/api/public/payments/webhook.ts) — never from client-callable code.
