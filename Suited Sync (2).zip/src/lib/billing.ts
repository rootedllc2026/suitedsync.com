import { useMutation, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { getMirrorUsage } from "@/lib/mirror.functions";
import { createPortalSession } from "@/lib/payments.functions";
import { getStripeEnvironment, paymentsConfigured } from "@/lib/stripe";
import type { Tables } from "@/integrations/supabase/types";

export const PRO_PRICE_ID = "pro_monthly";
export const PRO_PRICE_LABEL = "$9.99 / month";
export const FREE_MIRROR_QUOTA = 3;
export const PRO_MIRROR_QUOTA = 25;

export type Subscription = Tables<"subscriptions">;
export type PackPurchase = Tables<"mirror_pack_purchases">;

function env() {
  return paymentsConfigured() ? getStripeEnvironment() : "sandbox";
}

/** The member's most recent subscription row for this payment environment. */
export function useSubscription(userId: string | null) {
  return useQuery({
    queryKey: ["subscription", userId],
    enabled: !!userId,
    queryFn: async (): Promise<Subscription | null> => {
      const { data, error } = await supabase
        .from("subscriptions")
        .select("*")
        .eq("user_id", userId!)
        .eq("environment", env())
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
}

export function subscriptionIsActive(sub: Subscription | null | undefined): boolean {
  if (!sub) return false;
  const future = !sub.current_period_end || new Date(sub.current_period_end) > new Date();
  if (["active", "trialing", "past_due"].includes(sub.status)) return future;
  return sub.status === "canceled" && future;
}

/** Server-computed AI Mirror entitlement: plan allowance plus purchased packs. */
export function useEntitlement(userId: string | null, options?: { refetchInterval?: number }) {
  return useQuery({
    queryKey: ["entitlement", userId],
    enabled: !!userId,
    refetchInterval: options?.refetchInterval ?? false,
    queryFn: () => getMirrorUsage(),
  });
}

export function usePurchases(userId: string | null) {
  return useQuery({
    queryKey: ["purchases", userId],
    enabled: !!userId,
    queryFn: async (): Promise<PackPurchase[]> => {
      const { data, error } = await supabase
        .from("mirror_pack_purchases")
        .select("*")
        .eq("user_id", userId!)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

/** Opens the Stripe billing portal in a new tab. */
export function useBillingPortal() {
  return useMutation({
    mutationFn: async () => {
      const result = await createPortalSession({
        data: { returnUrl: `${window.location.origin}/billing`, environment: env() },
      });
      if ("error" in result) throw new Error(result.error);
      window.open(result.url, "_blank", "noopener");
    },
  });
}

export function formatMoney(cents: number | null, currency: string | null) {
  if (cents == null) return "—";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: (currency ?? "usd").toUpperCase(),
  }).format(cents / 100);
}
