/**
 * Shared resilience helpers for the two external APIs we depend on
 * (Lovable AI vision for tagging, FASHN for try-on): bounded retries with
 * exponential backoff, plus a dead-letter record so nothing fails silently.
 */

export type RetryOptions = {
  attempts?: number;
  baseMs?: number;
  label: string;
};

function statusOf(error: unknown) {
  return (error as { status?: number } | null)?.status;
}

/** True for failures that are worth trying again (rate limits, 5xx, network). */
export function isTransient(error: unknown) {
  const status = statusOf(error);
  if (status === undefined) return true; // network / abort / parse
  return status === 408 || status === 429 || status >= 500;
}

export async function withRetry<T>(fn: () => Promise<T>, options: RetryOptions): Promise<T> {
  const attempts = options.attempts ?? 3;
  const baseMs = options.baseMs ?? 700;
  let lastError: unknown;

  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (attempt === attempts || !isTransient(error)) break;
      const wait = baseMs * 2 ** (attempt - 1) + Math.floor(Math.random() * 250);
      console.warn(
        `[${options.label}] attempt ${attempt}/${attempts} failed, retrying in ${wait}ms`,
      );
      await new Promise((r) => setTimeout(r, wait));
    }
  }
  throw lastError;
}

/** Dead-letter record. Best-effort: logging must never mask the real error. */
export async function recordFailure(args: {
  userId: string | null;
  kind: string;
  payload: Record<string, unknown>;
  error: unknown;
  attempts?: number;
}) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("integration_failures").insert({
      user_id: args.userId,
      kind: args.kind,
      payload: args.payload as never,
      error: args.error instanceof Error ? args.error.message : String(args.error),
      attempts: args.attempts ?? 1,
    });
  } catch (loggingError) {
    console.error("[dead-letter] could not record failure", loggingError);
  }
}

/** Reads the global AI Mirror flag + per-user daily cap. */
export async function mirrorFlag() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("app_flags")
    .select("enabled, number_value")
    .eq("key", "ai_mirror")
    .maybeSingle();
  return { enabled: data?.enabled ?? true, dailyCap: data?.number_value ?? 15 };
}
