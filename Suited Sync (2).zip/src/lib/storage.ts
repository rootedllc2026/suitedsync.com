import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type PhotoBucket = "closet" | "reference-photos" | "mirror-previews";

export async function uploadPhoto(bucket: PhotoBucket, userId: string, file: File | Blob) {
  const ext = file instanceof File ? (file.name.split(".").pop() ?? "jpg") : "png";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    contentType: file.type || "image/jpeg",
    upsert: false,
  });
  if (error) throw error;
  return path;
}

export async function signPhoto(bucket: PhotoBucket, path: string, seconds = 3600) {
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, seconds);
  if (error) throw error;
  return data.signedUrl;
}

export function useSignedPhoto(bucket: PhotoBucket, path: string | null | undefined) {
  return useQuery({
    queryKey: ["signed", bucket, path],
    queryFn: () => signPhoto(bucket, path as string),
    enabled: !!path,
    staleTime: 45 * 60 * 1000,
  });
}

export async function removePhoto(bucket: PhotoBucket, path: string) {
  await supabase.storage.from(bucket).remove([path]);
}
