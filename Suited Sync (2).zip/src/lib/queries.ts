import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import type { ClosetItem, DailyOutfit, Formality, Profile } from "./wardrobe";

export type PortfolioEntry = Tables<"portfolio_entries">;

export function usePortfolio(userId: string | null) {
  return useQuery({
    queryKey: ["portfolio", userId],
    enabled: !!userId,
    queryFn: async (): Promise<PortfolioEntry[]> => {
      const { data, error } = await supabase
        .from("portfolio_entries")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useAddToPortfolio(userId: string | null) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (entry: {
      kind: "look" | "mirror";
      title?: string | null;
      eventLabel?: string | null;
      formality?: Formality | null;
      itemIds?: string[];
      imageBucket?: string | null;
      imagePath?: string | null;
      previewId?: string | null;
    }) => {
      const { data, error } = await supabase
        .from("portfolio_entries")
        .insert({
          user_id: userId!,
          kind: entry.kind,
          title: entry.title ?? null,
          event_label: entry.eventLabel ?? null,
          formality: entry.formality ?? null,
          item_ids: entry.itemIds ?? [],
          image_bucket: entry.imageBucket ?? null,
          image_path: entry.imagePath ?? null,
          preview_id: entry.previewId ?? null,
        })
        .select("*")
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["portfolio"] }),
  });
}

export function useRemoveFromPortfolio() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("portfolio_entries").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["portfolio"] }),
  });
}


export function useProfile(userId: string | null) {
  return useQuery({
    queryKey: ["profile", userId],
    enabled: !!userId,
    queryFn: async (): Promise<Profile | null> => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId!)
        .maybeSingle();
      if (error) throw error;
      if (data) return data;
      const { data: created, error: insertError } = await supabase
        .from("profiles")
        .insert({ id: userId! })
        .select("*")
        .single();
      if (insertError) throw insertError;
      return created;
    },
  });
}

export function useCloset(userId: string | null) {
  return useQuery({
    queryKey: ["closet", userId],
    enabled: !!userId,
    queryFn: async (): Promise<ClosetItem[]> => {
      const { data, error } = await supabase
        .from("closet_items")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useOutfits(userId: string | null) {
  return useQuery({
    queryKey: ["outfits", userId],
    enabled: !!userId,
    queryFn: async (): Promise<DailyOutfit[]> => {
      const { data, error } = await supabase
        .from("daily_outfits")
        .select("*")
        .order("outfit_date", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useMappings(userId: string | null) {
  return useQuery({
    queryKey: ["mappings", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase.from("event_type_mappings").select("*");
      if (error) throw error;
      return data ?? [];
    },
  });
}

export function useSavePlan(userId: string | null) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (plan: {
      outfitDate: string;
      eventLabel: string;
      formality: Formality;
      itemIds: string[];
      status?: "suggested" | "worn" | "skipped";
    }) => {
      const { data, error } = await supabase
        .from("daily_outfits")
        .upsert(
          {
            user_id: userId!,
            outfit_date: plan.outfitDate,
            event_label: plan.eventLabel,
            formality: plan.formality,
            item_ids: plan.itemIds,
            status: plan.status ?? "suggested",
            worn_at: plan.status === "worn" ? new Date().toISOString() : null,
          },
          { onConflict: "user_id,outfit_date" },
        )
        .select("*")
        .single();
      if (error) throw error;

      if (plan.status === "worn" && plan.itemIds.length) {
        await supabase
          .from("closet_items")
          .update({ last_worn_date: plan.outfitDate })
          .in("id", plan.itemIds);
      }
      return data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["outfits"] });
      qc.invalidateQueries({ queryKey: ["closet"] });
    },
  });
}

export function useSaveItem() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (patch: Partial<ClosetItem> & { id: string }) => {
      const { id, ...rest } = patch;
      const { error } = await supabase.from("closet_items").update(rest).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["closet"] }),
  });
}

export function useDeleteItem() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("closet_items").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["closet"] }),
  });
}

/** Bulk tag/availability correction across many pieces at once. */
export function useBulkUpdateItems() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { ids: string[]; patch: Partial<ClosetItem> }) => {
      if (!args.ids.length) return;
      const { error } = await supabase
        .from("closet_items")
        .update(args.patch)
        .in("id", args.ids);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["closet"] }),
  });
}

export function useBulkDeleteItems() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (ids: string[]) => {
      if (!ids.length) return;
      const { error } = await supabase.from("closet_items").delete().in("id", ids);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["closet"] }),
  });
}

export type ReferencePhoto = Tables<"reference_photos">;

/** Every reference photo (model shot) the member has uploaded. */
export function useReferencePhotos(userId: string | null) {
  return useQuery({
    queryKey: ["reference-photos", userId],
    enabled: !!userId,
    queryFn: async (): Promise<ReferencePhoto[]> => {
      const { data, error } = await supabase
        .from("reference_photos")
        .select("*")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data ?? [];
    },
  });
}

/** Logs the tags a user corrected after auto-tagging — free signal on prompt quality. */
export async function logTagCorrections(args: {
  userId: string;
  photoPath: string | null;
  provider: string;
  ai: Record<string, string | null>;
  final: Record<string, string | null>;
}) {
  const rows = Object.keys(args.final)
    .filter((field) => (args.ai[field] ?? "") !== (args.final[field] ?? ""))
    .map((field) => ({
      user_id: args.userId,
      photo_path: args.photoPath,
      field,
      ai_value: args.ai[field] ?? null,
      final_value: args.final[field] ?? null,
      provider: args.provider,
    }));
  if (!rows.length) return 0;
  await supabase.from("tag_corrections").insert(rows);
  return rows.length;
}
