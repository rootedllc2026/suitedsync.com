import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/** Funnel events we care about when pricing tiers. */
export type EventName =
  | "item_added"
  | "tag_corrected"
  | "outfit_regenerated"
  | "outfit_marked_worn"
  | "preview_requested"
  | "preview_generated"
  | "preview_failed"
  | "preview_saved"
  | "portfolio_added";

/** Fire-and-forget product analytics. Never blocks or throws into the UI. */
export function track(
  userId: string | null | undefined,
  name: EventName,
  props: Record<string, unknown> = {},
) {
  if (!userId) return;
  void supabase
    .from("analytics_events")
    .insert({ user_id: userId, name, props: props as never })
    .then(() => undefined, () => undefined);
}

export function useFunnel(userId: string | null) {
  return useQuery({
    queryKey: ["funnel", userId],
    enabled: !!userId,
    staleTime: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("analytics_events")
        .select("name, created_at")
        .order("created_at", { ascending: false })
        .limit(2000);
      if (error) throw error;
      const counts: Record<string, number> = {};
      for (const row of data ?? []) counts[row.name] = (counts[row.name] ?? 0) + 1;
      return counts;
    },
  });
}

export function useFailures(userId: string | null) {
  return useQuery({
    queryKey: ["failures", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("integration_failures")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data ?? [];
    },
  });
}
