import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { CheckSquare, Trash2, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ItemTile } from "@/components/ItemTile";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/useAuth";
import { useBulkDeleteItems, useBulkUpdateItems, useCloset } from "@/lib/queries";
import {
  AVAILABILITIES,
  AVAILABILITY_LABELS,
  CATEGORIES,
  CATEGORY_LABELS,
  FORMALITIES,
  FORMALITY_LABELS,
  availabilityOf,
  type Availability,
  type Category,
  type Formality,
} from "@/lib/wardrobe";

export const Route = createFileRoute("/closet/")({
  head: () => ({
    meta: [
      { title: "Your Closet — Suited Sync" },
      {
        name: "description",
        content:
          "Browse every tagged piece in your wardrobe, filtered by category, colour, formality and availability.",
      },
      { property: "og:title", content: "Your Closet — Suited Sync" },
      {
        property: "og:description",
        content: "A photo-forward view of everything hanging in your wardrobe.",
      },
    ],
  }),
  component: ClosetPage,
});

function ClosetPage() {
  const { userId } = useAuth();
  const closet = useCloset(userId);
  const bulkUpdate = useBulkUpdateItems();
  const bulkDelete = useBulkDeleteItems();
  const [category, setCategory] = useState<Category | "all">("all");
  const [formality, setFormality] = useState<Formality | "all">("all");
  const [availability, setAvailability] = useState<Availability | "all">("all");
  const [colour, setColour] = useState("");
  const [selecting, setSelecting] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);

  const items = closet.data ?? [];
  const filtered = useMemo(
    () =>
      items.filter(
        (i) =>
          (category === "all" || i.category === category) &&
          (formality === "all" || i.formality === formality) &&
          (availability === "all" || availabilityOf(i) === availability) &&
          (!colour.trim() ||
            (i.color ?? "").toLowerCase().includes(colour.trim().toLowerCase())),
      ),
    [items, category, formality, availability, colour],
  );

  const toggle = (id: string) =>
    setSelected((list) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]));

  const applyPatch = async (patch: Record<string, unknown>, message: string) => {
    await bulkUpdate.mutateAsync({ ids: selected, patch: patch as never });
    toast.success(`${selected.length} piece${selected.length === 1 ? "" : "s"} ${message}`);
    setSelected([]);
  };

  if (!userId) {
    return (
      <AppShell backdrop="closet">
        <p className="text-sm text-muted-foreground">Sign in to see your closet.</p>
      </AppShell>
    );
  }

  return (
    <AppShell backdrop="closet">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[0.7rem] uppercase tracking-[0.28em] text-accent">Wardrobe</p>
          <h1 className="mt-2 font-display text-4xl leading-tight">Your closet</h1>
        </div>
        <div className="flex items-center gap-3">
          <p className="text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
            {filtered.length} of {items.length} pieces
          </p>
          <Button
            size="sm"
            variant={selecting ? "accent" : "outline"}
            onClick={() => {
              setSelecting((v) => !v);
              setSelected([]);
            }}
          >
            {selecting ? (
              <>
                <X className="mr-2 h-3.5 w-3.5" /> Done
              </>
            ) : (
              <>
                <CheckSquare className="mr-2 h-3.5 w-3.5" /> Bulk edit
              </>
            )}
          </Button>
        </div>
      </header>

      <div className="mt-7 space-y-3">
        <div className="flex flex-wrap gap-1.5">
          {(["all", ...CATEGORIES] as const).map((c) => (
            <Button
              key={c}
              size="sm"
              variant={category === c ? "accent" : "outline"}
              onClick={() => setCategory(c as Category | "all")}
            >
              {c === "all" ? "All" : CATEGORY_LABELS[c as Category]}
            </Button>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {(["all", ...FORMALITIES] as const).map((f) => (
            <Button
              key={f}
              size="sm"
              variant={formality === f ? "accent" : "outline"}
              onClick={() => setFormality(f as Formality | "all")}
            >
              {f === "all" ? "Any dress code" : FORMALITY_LABELS[f as Formality]}
            </Button>
          ))}
          <Input
            value={colour}
            onChange={(e) => setColour(e.target.value)}
            placeholder="Filter by colour"
            className="h-9 w-40"
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {(["all", ...AVAILABILITIES] as const).map((a) => (
            <Button
              key={a}
              size="sm"
              variant={availability === a ? "accent" : "outline"}
              onClick={() => setAvailability(a as Availability | "all")}
            >
              {a === "all" ? "Any availability" : AVAILABILITY_LABELS[a as Availability]}
            </Button>
          ))}
        </div>
      </div>

      {selecting && (
        <div className="mt-6 space-y-3 rounded-sm border border-accent/40 bg-accent/5 p-4 animate-fade-up">
          <div className="flex flex-wrap items-center gap-3">
            <p className="text-sm">
              {selected.length} selected
              {selected.length === 0 ? " — tap pieces below to correct them together" : ""}
            </p>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setSelected(filtered.map((i) => i.id))}
            >
              Select all shown
            </Button>
            {selected.length > 0 && (
              <Button size="sm" variant="ghost" onClick={() => setSelected([])}>
                Clear
              </Button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Select
              disabled={!selected.length || bulkUpdate.isPending}
              onValueChange={(v) => void applyPatch({ category: v }, `re-tagged as ${CATEGORY_LABELS[v as Category].toLowerCase()}.`)}
            >
              <SelectTrigger className="h-9 w-44">
                <SelectValue placeholder="Set category" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    {CATEGORY_LABELS[c]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              disabled={!selected.length || bulkUpdate.isPending}
              onValueChange={(v) => void applyPatch({ formality: v }, `set to ${FORMALITY_LABELS[v as Formality].toLowerCase()}.`)}
            >
              <SelectTrigger className="h-9 w-48">
                <SelectValue placeholder="Set dress code" />
              </SelectTrigger>
              <SelectContent>
                {FORMALITIES.map((f) => (
                  <SelectItem key={f} value={f}>
                    {FORMALITY_LABELS[f]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select
              disabled={!selected.length || bulkUpdate.isPending}
              onValueChange={(v) => void applyPatch({ availability: v }, `moved to ${AVAILABILITY_LABELS[v as Availability].toLowerCase()}.`)}
            >
              <SelectTrigger className="h-9 w-48">
                <SelectValue placeholder="Set availability" />
              </SelectTrigger>
              <SelectContent>
                {AVAILABILITIES.map((a) => (
                  <SelectItem key={a} value={a}>
                    {AVAILABILITY_LABELS[a]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              size="sm"
              variant="ghost"
              disabled={!selected.length || bulkDelete.isPending}
              onClick={async () => {
                const count = selected.length;
                await bulkDelete.mutateAsync(selected);
                setSelected([]);
                toast.success(`${count} piece${count === 1 ? "" : "s"} removed.`);
              }}
            >
              <Trash2 className="mr-2 h-3.5 w-3.5" /> Delete selected
            </Button>
          </div>
        </div>
      )}

      {filtered.length === 0 ? (
        <p className="mt-14 text-sm text-muted-foreground">
          Nothing matches those filters yet.
        </p>
      ) : (
        <div className="mt-9 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
          {filtered.map((item) => (
            <ItemTile
              key={item.id}
              item={item}
              selectable={selecting}
              selected={selected.includes(item.id)}
              onToggle={() => toggle(item.id)}
            />
          ))}
        </div>
      )}
    </AppShell>
  );
}
