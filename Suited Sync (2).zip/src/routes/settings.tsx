import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useRef, useState } from "react";
import { CalendarDays, Lock, ShieldOff, Star, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { PhotoFrame } from "@/components/PhotoFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import type { TablesUpdate } from "@/integrations/supabase/types";
import { removePhoto, uploadPhoto } from "@/lib/storage";
import { useProfile, useReferencePhotos } from "@/lib/queries";
import { deleteMyData, purgeOldPreviews } from "@/lib/account.functions";
import { useAuth } from "@/lib/useAuth";
import { useEntitlement } from "@/lib/billing";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — Suited Sync" },
      {
        name: "description",
        content:
          "Manage your re-wear cooldown, calendar connection, private reference photos and data retention.",
      },
      { property: "og:title", content: "Settings — Suited Sync" },
      {
        property: "og:description",
        content: "Manage your styling preferences, AI Mirror model shots and privacy controls.",
      },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { userId } = useAuth();
  const profile = useProfile(userId);
  const photos = useReferencePhotos(userId);
  const entitlement = useEntitlement(userId);
  const qc = useQueryClient();
  const purge = useServerFn(purgeOldPreviews);
  const wipe = useServerFn(deleteMyData);

  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["profile"] });
    qc.invalidateQueries({ queryKey: ["reference-photos"] });
  };

  const update = async (patch: TablesUpdate<"profiles">) => {
    if (!userId) return;
    const { error } = await supabase.from("profiles").update(patch).eq("id", userId);
    if (error) {
      toast.error(error.message);
      return;
    }
    refresh();
  };

  if (!userId) {
    return (
      <AppShell>
        <p className="text-sm text-muted-foreground">Sign in to manage your settings.</p>
      </AppShell>
    );
  }

  const data = profile.data;
  const shots = photos.data ?? [];

  const addPhotos = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    try {
      let first = shots.length === 0;
      for (const file of Array.from(files).slice(0, 5)) {
        const path = await uploadPhoto("reference-photos", userId, file);
        const { error } = await supabase
          .from("reference_photos")
          .insert({ user_id: userId, storage_path: path, is_primary: first });
        if (error) throw error;
        if (first) {
          await update({ reference_photo_url: path });
          first = false;
        }
      }
      refresh();
      toast.success("Model shots saved privately.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  };

  const makePrimary = async (id: string, path: string) => {
    await supabase.from("reference_photos").update({ is_primary: false }).eq("user_id", userId);
    await supabase.from("reference_photos").update({ is_primary: true }).eq("id", id);
    await update({ reference_photo_url: path });
    toast.success("Default model shot updated.");
  };

  const removeShot = async (id: string, path: string, wasPrimary: boolean) => {
    await supabase.from("reference_photos").delete().eq("id", id);
    await removePhoto("reference-photos", path);
    const remaining = shots.filter((s) => s.id !== id);
    if (wasPrimary) {
      const next = remaining[0];
      if (next) await makePrimary(next.id, next.storage_path);
      else await update({ reference_photo_url: null });
    }
    refresh();
    toast.success("Photo deleted.");
  };

  return (
    <AppShell>
      <header className="max-w-xl">
        <p className="text-[0.7rem] uppercase tracking-[0.28em] text-accent">Preferences</p>
        <h1 className="mt-2 font-display text-4xl leading-tight">Settings</h1>
      </header>

      <div className="mt-10 grid gap-12 md:grid-cols-2">
        <section>
          <h2 className="font-display text-2xl">AI Mirror model shots</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Upload a few front-facing, full-body photos in a neutral pose — different poses and
            lighting noticeably improve try-on results, and you can pick which one a preview uses.
            Entirely optional: every other feature works without them.
          </p>

          <div className="mt-5 grid grid-cols-3 gap-3">
            {shots.map((shot) => (
              <div key={shot.id} className="space-y-2">
                <div className="relative">
                  <PhotoFrame
                    bucket="reference-photos"
                    path={shot.storage_path}
                    alt="Your reference photo"
                    className="aspect-[3/4] rounded-sm"
                    fallbackLabel="Photo"
                  />
                  {shot.is_primary && (
                    <span className="absolute left-1.5 top-1.5 bg-accent px-1.5 py-0.5 text-[0.5rem] uppercase tracking-[0.16em] text-accent-foreground">
                      Default
                    </span>
                  )}
                </div>
                <div className="flex gap-1">
                  {!shot.is_primary && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="px-2"
                      onClick={() => void makePrimary(shot.id, shot.storage_path)}
                    >
                      <Star className="h-3 w-3" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="px-2"
                    onClick={() => void removeShot(shot.id, shot.storage_path, shot.is_primary)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
            {shots.length === 0 && (
              <PhotoFrame
                bucket="reference-photos"
                path={null}
                alt="No reference photo yet"
                className="aspect-[3/4] rounded-sm"
                fallbackLabel="No photo"
              />
            )}
          </div>

          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            hidden
            onChange={(e) => {
              void addPhotos(e.target.files);
              e.target.value = "";
            }}
          />
          <Button
            variant="accent"
            size="sm"
            className="mt-4"
            disabled={busy}
            onClick={() => fileRef.current?.click()}
          >
            <Upload className="mr-2 h-3.5 w-3.5" />
            {shots.length ? "Add more shots" : "Upload model shots"}
          </Button>

          <p className="mt-5 flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
            <Lock className="mt-0.5 h-3 w-3 shrink-0" />
            Your reference photos are used only to generate your own try-on previews. They are stored
            privately, are never shared publicly or with other users, and you can delete them at any
            time.
          </p>

          <div className="mt-7 rounded-sm border border-border p-4">
            <p className="text-sm">
              {entitlement.data?.used ?? 0} of {entitlement.data?.monthly_quota ?? 3} AI Mirror
              previews used this month
              {entitlement.data?.pack_balance
                ? ` — ${entitlement.data.pack_balance} in reserve`
                : ""}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Your allowance resets at the start of each month. Need more? An extra pack adds 10
              previews to this cycle for $4.99.
            </p>
            <Button variant="outline" size="sm" className="mt-3" asChild>
              <Link to="/billing">Manage membership & packs</Link>
            </Button>
          </div>
        </section>


        <section className="space-y-10">
          <div>
            <h2 className="font-display text-2xl">Styling</h2>
            <div className="mt-4 max-w-56 space-y-1.5">
              <Label htmlFor="cooldown">Re-wear cooldown (days)</Label>
              <Input
                id="cooldown"
                type="number"
                min={0}
                max={90}
                defaultValue={data?.cooldown_days ?? 14}
                onBlur={(e) => update({ cooldown_days: Number(e.target.value) || 0 })}
              />
              <p className="text-xs text-muted-foreground">
                A combination you've worn won't be suggested again inside this window.
              </p>
            </div>
            <div className="mt-5 max-w-56 space-y-1.5">
              <Label htmlFor="name">Display name</Label>
              <Input
                id="name"
                defaultValue={data?.display_name ?? ""}
                onBlur={(e) => update({ display_name: e.target.value.trim() || null })}
              />
            </div>
          </div>

          <div>
            <h2 className="flex items-center gap-2 font-display text-2xl">
              <CalendarDays className="h-4 w-4 text-accent" /> Calendar
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {data?.calendar_connected
                ? `Connected to ${data.calendar_provider ?? "your calendar"} (read-only). Each day's event type is inferred from your entries and can be corrected on the Today screen.`
                : "No calendar connected yet. Until one is, set each day's event type yourself on the Today screen — the evening before works well."}
            </p>
            {data?.calendar_connected && (
              <Button
                variant="ghost"
                size="sm"
                className="mt-3"
                onClick={() => update({ calendar_connected: false, calendar_provider: null })}
              >
                Disconnect calendar
              </Button>
            )}
          </div>

          <div>
            <h2 className="flex items-center gap-2 font-display text-2xl">
              <ShieldOff className="h-4 w-4 text-accent" /> Privacy & retention
            </h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Previews you don't save are kept for 30 days and then deleted along with their image
              files. You can clear them now, or erase everything we hold — closet photos, model
              shots, previews, outfits and your portfolio.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={busy}
                onClick={async () => {
                  setBusy(true);
                  try {
                    const result = await purge({ data: undefined });
                    toast.success(
                      result.removed
                        ? `${result.removed} old preview${result.removed === 1 ? "" : "s"} purged.`
                        : "Nothing older than 30 days to purge.",
                    );
                  } catch (error) {
                    toast.error(error instanceof Error ? error.message : "Purge failed");
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                Purge unsaved previews now
              </Button>
              <Button
                variant="ghost"
                size="sm"
                disabled={busy}
                onClick={async () => {
                  if (
                    !window.confirm(
                      "Delete every photo, outfit, preview and portfolio entry in your account? This cannot be undone.",
                    )
                  )
                    return;
                  setBusy(true);
                  try {
                    await wipe({ data: undefined });
                    qc.clear();
                    toast.success("All of your wardrobe data has been deleted.");
                  } catch (error) {
                    toast.error(error instanceof Error ? error.message : "Deletion failed");
                  } finally {
                    setBusy(false);
                  }
                }}
              >
                <Trash2 className="mr-2 h-3.5 w-3.5" /> Delete all my data
              </Button>
            </div>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
