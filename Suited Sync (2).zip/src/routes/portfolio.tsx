import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Sparkles, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { PhotoFrame } from "@/components/PhotoFrame";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/useAuth";
import {
  useCloset,
  usePortfolio,
  useRemoveFromPortfolio,
  type PortfolioEntry,
} from "@/lib/queries";
import type { PhotoBucket } from "@/lib/storage";
import { CATEGORY_LABELS, FORMALITY_LABELS, type ClosetItem } from "@/lib/wardrobe";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Model Portfolio — Suited Sync" },
      {
        name: "description",
        content:
          "Your private lookbook: every look you've chosen and every AI Mirror preview you've kept, laid out like a model portfolio.",
      },
      { property: "og:title", content: "Model Portfolio — Suited Sync" },
      {
        property: "og:description",
        content: "A black, red and white lookbook of your chosen looks and try-on previews.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PortfolioPage,
});

function PortfolioPage() {
  const { userId } = useAuth();
  const portfolio = usePortfolio(userId);
  const closet = useCloset(userId);
  const remove = useRemoveFromPortfolio();
  const [open, setOpen] = useState<PortfolioEntry | null>(null);

  const entries = portfolio.data ?? [];
  const itemsFor = (entry: PortfolioEntry): ClosetItem[] =>
    entry.item_ids
      .map((id) => (closet.data ?? []).find((i) => i.id === id))
      .filter((i): i is ClosetItem => !!i);

  if (!userId) {
    return (
      <AppShell backdrop>
        <p className="text-sm text-muted-foreground">Sign in to see your portfolio.</p>
      </AppShell>
    );
  }

  return (
    <AppShell backdrop>
      <header className="max-w-xl">
        <p className="flex items-center gap-1.5 text-[0.7rem] uppercase tracking-[0.28em] text-accent">
          <Sparkles className="h-3 w-3" /> Lookbook
        </p>
        <h1 className="mt-2 font-display text-4xl leading-tight md:text-5xl">Model portfolio</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Every look you've chosen and every AI Mirror preview you've kept. Tap a page to open it.
          Private to your account.
        </p>
      </header>

      {entries.length === 0 ? (
        <div className="mt-12 rounded-sm border border-dashed border-border p-10 text-center">
          <p className="font-display text-2xl">Your portfolio is empty</p>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            Add a look from Today, or generate an AI Mirror preview and keep it here.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-2">
            <Button variant="accent" asChild>
              <Link to="/">Choose today's look</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/mirror">Open AI Mirror</Link>
            </Button>
          </div>
        </div>
      ) : (
        <div className="mt-10 grid grid-cols-2 gap-5 sm:grid-cols-3 lg:grid-cols-4">
          {entries.map((entry) => {
            const looks = itemsFor(entry);
            return (
              <button
                key={entry.id}
                onClick={() => setOpen(entry)}
                className="group animate-fade-up text-left"
              >
                <div className="relative overflow-hidden rounded-sm border border-border bg-secondary shadow-lookbook transition-transform duration-300 group-hover:scale-[1.01]">
                  {entry.image_path ? (
                    <PhotoFrame
                      bucket={(entry.image_bucket ?? "mirror-previews") as PhotoBucket}
                      path={entry.image_path}
                      alt={entry.title || "Portfolio look"}
                      className="aspect-[3/4]"
                      fallbackLabel="Preview"
                    />
                  ) : (
                    <div className="grid aspect-[3/4] grid-cols-2 gap-px bg-border/40">
                      {looks.slice(0, 4).map((item) => (
                        <PhotoFrame
                          key={item.id}
                          path={item.photo_url}
                          alt={item.name || CATEGORY_LABELS[item.category]}
                          className="h-full w-full"
                          fallbackLabel="—"
                        />
                      ))}
                    </div>
                  )}
                  <span className="absolute left-0 top-0 bg-accent px-2 py-1 text-[0.6rem] uppercase tracking-[0.18em] text-accent-foreground">
                    {entry.kind === "mirror" ? "Mirror" : "Look"}
                  </span>
                </div>
                <p className="mt-3 truncate text-sm">{entry.title || "Untitled look"}</p>
                <p className="text-[0.66rem] uppercase tracking-[0.16em] text-muted-foreground">
                  {entry.formality ? FORMALITY_LABELS[entry.formality] : entry.event_label ?? "—"}
                </p>
              </button>
            );
          })}
        </div>
      )}

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 p-5 backdrop-blur"
          onClick={() => setOpen(null)}
        >
          <div
            className="max-h-full w-full max-w-3xl overflow-y-auto rounded-sm border border-border bg-card p-6 shadow-lift animate-fade-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="text-[0.66rem] uppercase tracking-[0.18em] text-accent">
                  {open.kind === "mirror" ? "AI Mirror preview" : "Chosen look"}
                </p>
                <h2 className="mt-1 truncate font-display text-3xl">
                  {open.title || "Untitled look"}
                </h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  {open.event_label ?? "—"}
                  {open.formality ? ` · ${FORMALITY_LABELS[open.formality]}` : ""}
                </p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setOpen(null)}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <div className="mt-6 grid gap-6 md:grid-cols-2">
              {open.image_path && (
                <PhotoFrame
                  bucket={(open.image_bucket ?? "mirror-previews") as PhotoBucket}
                  path={open.image_path}
                  alt={open.title || "Portfolio preview"}
                  className="aspect-[3/4] rounded-sm"
                  fallbackLabel="Preview"
                />
              )}
              <div className="grid grid-cols-2 gap-3">
                {itemsFor(open).map((item) => (
                  <figure key={item.id} className="space-y-1.5">
                    <PhotoFrame
                      path={item.photo_url}
                      alt={item.name || CATEGORY_LABELS[item.category]}
                      className="aspect-[3/4] rounded-sm"
                      fallbackLabel={CATEGORY_LABELS[item.category]}
                    />
                    <figcaption className="truncate text-xs text-muted-foreground">
                      {item.name || CATEGORY_LABELS[item.category]}
                    </figcaption>
                  </figure>
                ))}
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  await remove.mutateAsync(open.id);
                  setOpen(null);
                  toast.success("Removed from your portfolio.");
                }}
              >
                <Trash2 className="mr-2 h-3.5 w-3.5" /> Remove
              </Button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}
