import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, Bookmark, Download, FolderPlus, Share2, Sparkles, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { AppShell } from "@/components/AppShell";
import { PhotoFrame } from "@/components/PhotoFrame";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { generateMirrorPreview } from "@/lib/mirror.functions";
import { signPhoto } from "@/lib/storage";
import { useAddToPortfolio, useCloset, useOutfits, useProfile, useReferencePhotos } from "@/lib/queries";
import { track } from "@/lib/analytics";
import { useAuth } from "@/lib/useAuth";
import { useEntitlement } from "@/lib/billing";
import { CATEGORY_LABELS, prettyDate, todayISO, type ClosetItem } from "@/lib/wardrobe";

export const Route = createFileRoute("/mirror")({
  validateSearch: z.object({ date: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "AI Mirror — Suited Sync" },
      {
        name: "description",
        content:
          "See a suggested outfit rendered on your own reference photo before you get dressed.",
      },
      { property: "og:title", content: "AI Mirror — Suited Sync" },
      {
        property: "og:description",
        content: "A private virtual try-on preview of today's suggested outfit.",
      },
    ],
  }),
  component: MirrorPage,
});

function MirrorPage() {
  const { date } = Route.useSearch();
  const iso = date ?? todayISO();
  const { userId } = useAuth();
  const closet = useCloset(userId);
  const outfits = useOutfits(userId);
  const profile = useProfile(userId);
  const qc = useQueryClient();
  const generate = useServerFn(generateMirrorPreview);

  const addToPortfolio = useAddToPortfolio(userId);
  const referencePhotos = useReferencePhotos(userId);
  const [state, setState] = useState<"idle" | "working" | "done">("idle");
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [imagePath, setImagePath] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [inPortfolio, setInPortfolio] = useState(false);
  const [modelShot, setModelShot] = useState<string | null>(null);


  const plan = (outfits.data ?? []).find((o) => o.outfit_date === iso);
  const items: ClosetItem[] = (plan?.item_ids ?? [])
    .map((id) => (closet.data ?? []).find((i) => i.id === id))
    .filter((i): i is ClosetItem => !!i);

  const entitlement = useEntitlement(userId);
  const ent = entitlement.data;
  const used = ent?.used ?? 0;
  const quota = ent?.monthly_quota ?? 3;
  const packBalance = ent?.pack_balance ?? 0;
  const remaining = ent?.remaining ?? 0;
  const outOfPreviews = !!ent && remaining <= 0;
  const shots = referencePhotos.data ?? [];
  const activeShot =
    modelShot ?? shots.find((s) => s.is_primary)?.storage_path ?? profile.data?.reference_photo_url ?? null;
  const hasReference = !!activeShot;

  const signedResult = useQuery({
    queryKey: ["mirror-image", imagePath],
    enabled: !!imagePath,
    queryFn: () => signPhoto("mirror-previews", imagePath!, 3600),
  });

  const run = async () => {
    setState("working");
    track(userId, "preview_requested", { date: iso, items: items.length });
    try {
      const result = await generate({
        data: {
          outfitId: plan?.id ?? null,
          referencePath: activeShot,
          garments: items.map((i) => ({ path: i.photo_url ?? "", category: i.category })).filter(
            (g) => g.path,
          ),
        },
      });
      setPreviewId(result.previewId);
      setImagePath(result.imagePath);
      setSaved(false);
      setInPortfolio(false);

      setState("done");
      track(userId, "preview_generated", { date: iso });
      qc.invalidateQueries({ queryKey: ["profile"] });
      qc.invalidateQueries({ queryKey: ["entitlement"] });
    } catch (error) {
      setState("idle");
      track(userId, "preview_failed", {
        date: iso,
        message: error instanceof Error ? error.message : "unknown",
      });
      toast.error(error instanceof Error ? error.message : "Could not generate the preview.");
    }
  };

  if (!userId) {
    return (
      <AppShell>
        <p className="text-sm text-muted-foreground">Sign in to use AI Mirror.</p>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <Link
        to="/"
        className="inline-flex items-center gap-1.5 text-[0.7rem] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3 w-3" /> Today
      </Link>

      <header className="mt-6 max-w-xl">
        <p className="flex items-center gap-1.5 text-[0.7rem] uppercase tracking-[0.28em] text-accent">
          <Sparkles className="h-3 w-3" /> AI Mirror
        </p>
        <h1 className="mt-2 font-display text-4xl leading-tight">{prettyDate(iso)}</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          {plan?.event_label ?? "Your look"} — rendered on your own reference photo, privately.
        </p>
      </header>

      <div className="mt-10 grid gap-10 md:grid-cols-[1fr_1.1fr]">
        <section>
          <h2 className="text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
            The outfit
          </h2>
          <div className="mt-3 grid grid-cols-3 gap-2">
            {items.map((item) => (
              <PhotoFrame
                key={item.id}
                path={item.photo_url}
                alt={item.name || CATEGORY_LABELS[item.category]}
                className="aspect-[3/4] rounded-sm"
                fallbackLabel={CATEGORY_LABELS[item.category]}
              />
            ))}
          </div>

          {shots.length > 1 && (
            <>
              <h2 className="mt-7 text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
                Your model shot
              </h2>
              <div className="mt-3 flex gap-2">
                {shots.map((shot) => (
                  <button
                    key={shot.id}
                    type="button"
                    onClick={() => setModelShot(shot.storage_path)}
                    className={`w-20 rounded-sm ${
                      activeShot === shot.storage_path ? "ring-1 ring-accent" : "opacity-70"
                    }`}
                  >
                    <PhotoFrame
                      bucket="reference-photos"
                      path={shot.storage_path}
                      alt="Reference photo option"
                      className="aspect-[3/4] rounded-sm"
                      fallbackLabel="Shot"
                    />
                  </button>
                ))}
              </div>
            </>
          )}

          <p className="mt-6 text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
            {used}/{quota} previews used this month
            {packBalance > 0 ? ` — ${packBalance} in reserve` : ""}
            {ent ? ` — ${ent.tier === "pro" ? "Pro" : "Free"} plan` : ""}
          </p>

          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              variant="accent"
              disabled={!hasReference || state === "working" || !items.length || outOfPreviews}
              onClick={run}
            >
              <Wand2 className="mr-2 h-4 w-4" />
              {state === "working"
                ? "Styling…"
                : state === "done"
                  ? "Generate again"
                  : "Preview on me"}
            </Button>
            <Button variant="outline" asChild>
              <Link to="/">Try a different outfit</Link>
            </Button>
          </div>

          {!hasReference && (
            <p className="mt-4 text-xs text-muted-foreground">
              Add a full-body reference photo in{" "}
              <Link to="/settings" className="underline underline-offset-4">
                Settings
              </Link>{" "}
              to enable AI Mirror. Everything else keeps working without it.
            </p>
          )}
          {outOfPreviews && (
            <p className="mt-4 text-xs text-accent">
              You're out of previews.{" "}
              <Link to="/billing" className="underline underline-offset-4">
                {ent?.tier === "pro" ? "Add an extra pack" : "Go Pro or add a pack"}
              </Link>{" "}
              to keep going.
            </p>
          )}
        </section>

        <section>
          <div className="relative aspect-[3/4] overflow-hidden rounded-sm bg-secondary">
            {state === "working" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                <div className="h-full w-full animate-shimmer bg-[linear-gradient(110deg,transparent_25%,var(--color-background)_50%,transparent_75%)] opacity-70" />
                <p className="absolute bottom-8 text-[0.66rem] uppercase tracking-[0.22em] text-muted-foreground">
                  Dressing you now
                </p>
              </div>
            )}

            {state === "done" && signedResult.data && (
              <img
                src={signedResult.data}
                alt="You wearing the suggested outfit"
                className="h-full w-full animate-reveal object-cover"
              />
            )}

            {state === "idle" && (
              <div className="flex h-full items-center justify-center px-8 text-center">
                <p className="text-sm text-muted-foreground">
                  Your preview will appear here.
                </p>
              </div>
            )}
          </div>

          {state === "done" && (
            <div className="mt-4 flex flex-wrap gap-2 animate-fade-up">
              <Button
                variant={saved ? "ghost" : "outline"}
                size="sm"
                onClick={async () => {
                  if (!previewId) return;
                  await supabase
                    .from("ai_mirror_previews")
                    .update({ saved: true })
                    .eq("id", previewId);
                  setSaved(true);
                  track(userId, "preview_saved", { date: iso });
                  toast.success("Saved to your previews.");
                }}
              >
                <Bookmark className="mr-2 h-3.5 w-3.5" /> {saved ? "Saved" : "Save preview"}
              </Button>
              <Button
                variant="accent"
                size="sm"
                disabled={inPortfolio || addToPortfolio.isPending || !imagePath}
                onClick={async () => {
                  if (!imagePath) return;
                  await addToPortfolio.mutateAsync({
                    kind: "mirror",
                    title: `${plan?.event_label ?? "Look"} — ${prettyDate(iso)}`,
                    eventLabel: plan?.event_label ?? null,
                    formality: plan?.formality ?? null,
                    itemIds: items.map((i) => i.id),
                    imageBucket: "mirror-previews",
                    imagePath,
                    previewId,
                  });
                  setInPortfolio(true);
                  track(userId, "portfolio_added", { kind: "mirror", date: iso });
                  toast.success("Added to your model portfolio.");
                }}
              >
                <FolderPlus className="mr-2 h-3.5 w-3.5" />
                {inPortfolio ? "In portfolio" : "Add to portfolio"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  if (!signedResult.data) return;
                  try {
                    const res = await fetch(signedResult.data);
                    const blob = await res.blob();
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = `suited-sync-${iso}.png`;
                    document.body.appendChild(a);
                    a.click();
                    a.remove();
                    URL.revokeObjectURL(url);
                  } catch {
                    toast.error("Could not download the image.");
                  }
                }}
              >
                <Download className="mr-2 h-3.5 w-3.5" /> Download
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  if (!signedResult.data) return;
                  try {
                    const res = await fetch(signedResult.data);
                    const blob = await res.blob();
                    const file = new File([blob], `suited-sync-${iso}.png`, { type: blob.type });
                    if (navigator.canShare?.({ files: [file] })) {
                      await navigator.share({ files: [file], title: "My Suited Sync look" });
                      return;
                    }
                  } catch {
                    /* fall through to link sharing */
                  }
                  if (navigator.share) {
                    await navigator.share({ title: "My Suited Sync look", url: signedResult.data });
                  } else {
                    await navigator.clipboard.writeText(signedResult.data);
                    toast.success("Private link copied — it expires in an hour.");
                  }
                }}
              >
                <Share2 className="mr-2 h-3.5 w-3.5" /> Share
              </Button>
            </div>
          )}

        </section>
      </div>
    </AppShell>
  );
}
