import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { Loader2, Plus, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { PhotoFrame } from "@/components/PhotoFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { autoTagItem } from "@/lib/tagging.functions";
import { logTagCorrections } from "@/lib/queries";
import { track } from "@/lib/analytics";
import { uploadPhoto } from "@/lib/storage";
import { useAuth } from "@/lib/useAuth";
import {
  CATEGORIES,
  CATEGORY_LABELS,
  FORMALITIES,
  FORMALITY_LABELS,
  type Category,
  type Formality,
} from "@/lib/wardrobe";

export const Route = createFileRoute("/add")({
  head: () => ({
    meta: [
      { title: "Add closet items — Suited Sync" },
      {
        name: "description",
        content:
          "Photograph pieces individually or in batches, review the auto-generated tags, then save them to your closet.",
      },
      { property: "og:title", content: "Add closet items — Suited Sync" },
      {
        property: "og:description",
        content: "Auto-tag your wardrobe photos by category, colour and formality, then confirm.",
      },
    ],
  }),
  component: AddPage,
});

type Draft = {
  key: string;
  photoPath: string | null;
  name: string;
  category: Category;
  formality: Formality;
  color: string;
  colorHex: string | null;
  pattern: string;
  autoTagged: boolean;
  tagging: boolean;
  note?: string;
  /** What the model originally suggested, for the tag-QA loop. */
  ai?: Record<string, string | null>;
  provider?: string;
};

/** Drafts survive a reload or a failed batch so intake work is never lost. */
const DRAFTS_KEY = "suited-sync.intake-drafts";

function AddPage() {
  const { userId } = useAuth();
  const tag = useServerFn(autoTagItem);
  const fileRef = useRef<HTMLInputElement>(null);
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [saving, setSaving] = useState(false);
  const [restored, setRestored] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(DRAFTS_KEY);
      const parsed = raw ? (JSON.parse(raw) as Draft[]) : [];
      if (parsed.length) {
        setDrafts(parsed.map((d) => ({ ...d, tagging: false })));
        setRestored(true);
      }
    } catch {
      /* ignore unreadable drafts */
    }
  }, []);

  useEffect(() => {
    try {
      if (drafts.length) window.localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts));
      else window.localStorage.removeItem(DRAFTS_KEY);
    } catch {
      /* storage full or unavailable */
    }
  }, [drafts]);

  const patch = (key: string, next: Partial<Draft>) =>
    setDrafts((list) => list.map((d) => (d.key === key ? { ...d, ...next } : d)));

  const handleFiles = async (files: FileList | null) => {
    if (!files?.length || !userId) return;
    const chosen = Array.from(files);

    for (const file of chosen) {
      const key = crypto.randomUUID();
      setDrafts((list) => [
        ...list,
        {
          key,
          photoPath: null,
          name: "",
          category: "top",
          formality: "business_casual",
          color: "",
          colorHex: null,
          pattern: "",
          autoTagged: false,
          tagging: true,
        },
      ]);

      try {
        const photoPath = await uploadPhoto("closet", userId, file);
        patch(key, { photoPath });
        const result = await tag({ data: { photoPath } });
        patch(key, {
          ai: {
            name: result.name,
            category: result.category,
            formality: result.formality,
            color: result.color ?? "",
            pattern: result.pattern ?? "",
          },
          provider: result.provider,
          name: result.name,
          category: result.category,
          formality: result.formality,
          color: result.color ?? "",
          colorHex: result.colorHex,
          pattern: result.pattern ?? "",
          autoTagged: result.provider !== "none",
          tagging: false,
          ...(result.note ? { note: result.note } : {}),
        });
      } catch (error) {
        patch(key, {
          tagging: false,
          note: error instanceof Error ? error.message : "Upload failed — try again.",
        });
      }
    }
  };

  const addManual = () =>
    setDrafts((list) => [
      ...list,
      {
        key: crypto.randomUUID(),
        photoPath: null,
        name: "",
        category: "top",
        formality: "business_casual",
        color: "",
        colorHex: null,
        pattern: "",
        autoTagged: false,
        tagging: false,
      },
    ]);

  const saveAll = async () => {
    if (!userId || !drafts.length) return;
    setSaving(true);
    try {
      const rows = drafts.map((d) => ({
        user_id: userId,
        name: d.name.trim() || CATEGORY_LABELS[d.category],
        category: d.category,
        formality: d.formality,
        color: d.color.trim() || null,
        color_hex: d.colorHex,
        pattern: d.pattern.trim() || null,
        photo_url: d.photoPath,
        auto_tagged: d.autoTagged,
        tags_confirmed: true,
      }));
      const { error } = await supabase.from("closet_items").insert(rows);
      if (error) throw error;

      // Log every tag the member corrected — free signal on where the vision prompt is weak.
      for (const d of drafts) {
        if (!d.ai) continue;
        const corrected = await logTagCorrections({
          userId,
          photoPath: d.photoPath,
          provider: d.provider ?? "lovable-ai",
          ai: d.ai,
          final: {
            name: d.name.trim(),
            category: d.category,
            formality: d.formality,
            color: d.color.trim(),
            pattern: d.pattern.trim(),
          },
        }).catch(() => 0);
        if (corrected) track(userId, "tag_corrected", { fields: corrected });
      }
      track(userId, "item_added", { count: rows.length });

      toast.success(`${rows.length} piece${rows.length > 1 ? "s" : ""} added to your closet.`);
      setDrafts([]);
      setRestored(false);
    } catch (error) {
      toast.error(
        error instanceof Error
          ? `${error.message} — your drafts are kept here, try saving again.`
          : "Could not save your items — your drafts are kept here.",
      );
    } finally {
      setSaving(false);
    }
  };

  if (!userId) {
    return (
      <AppShell backdrop="closet">
        <p className="text-sm text-muted-foreground">Sign in to build your closet.</p>
      </AppShell>
    );
  }

  return (
    <AppShell backdrop="closet">
      <header className="max-w-xl">
        <p className="text-[0.7rem] uppercase tracking-[0.28em] text-accent">Closet intake</p>
        <h1 className="mt-2 font-display text-4xl leading-tight">Add pieces</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Photograph items one at a time or in batches — hung, folded or worn all work. Each photo is
          auto-tagged with category, colour and formality, and nothing is saved until you confirm.
        </p>
      </header>

      {restored && drafts.length > 0 && (
        <p className="mt-6 rounded-sm border border-accent/40 bg-accent/5 p-3 text-xs text-accent">
          Picked up {drafts.length} unsaved draft{drafts.length === 1 ? "" : "s"} from your last
          session — review and save them below.
        </p>
      )}

      <div className="mt-7 flex flex-wrap gap-2">
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          multiple
          hidden
          onChange={(e) => {
            void handleFiles(e.target.files);
            e.target.value = "";
          }}
        />
        <Button variant="accent" onClick={() => fileRef.current?.click()}>
          <Upload className="mr-2 h-4 w-4" /> Upload photos
        </Button>
        <Button variant="outline" onClick={addManual}>
          <Plus className="mr-2 h-4 w-4" /> Add without a photo
        </Button>
      </div>

      {drafts.length === 0 ? (
        <p className="mt-12 text-sm text-muted-foreground">
          Nothing waiting for review yet.
        </p>
      ) : (
        <>
          <h2 className="mt-12 font-display text-2xl">Review tags</h2>
          <div className="mt-5 space-y-4">
            {drafts.map((draft) => (
              <div
                key={draft.key}
                className="grid animate-fade-up gap-5 rounded-sm border border-border p-4 md:grid-cols-[9rem_1fr]"
              >
                <PhotoFrame
                  path={draft.photoPath}
                  alt={draft.name || "New closet item"}
                  className="aspect-[3/4] w-full rounded-sm md:w-36"
                  fallbackLabel={draft.tagging ? "Uploading" : "Manual entry"}
                />

                <div className="space-y-4">
                  {draft.tagging && (
                    <p className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Loader2 className="h-3 w-3 animate-spin" /> Reading the garment…
                    </p>
                  )}
                  {draft.note && <p className="text-xs text-accent">{draft.note}</p>}

                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="space-y-1.5">
                      <Label>Name</Label>
                      <Input
                        value={draft.name}
                        placeholder="Ivory silk blouse"
                        onChange={(e) => patch(draft.key, { name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Colour</Label>
                      <Input
                        value={draft.color}
                        placeholder="Ivory"
                        onChange={(e) => patch(draft.key, { color: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label>Category</Label>
                      <Select
                        value={draft.category}
                        onValueChange={(v) => patch(draft.key, { category: v as Category })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map((c) => (
                            <SelectItem key={c} value={c}>
                              {CATEGORY_LABELS[c]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label>Formality</Label>
                      <Select
                        value={draft.formality}
                        onValueChange={(v) => patch(draft.key, { formality: v as Formality })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {FORMALITIES.map((f) => (
                            <SelectItem key={f} value={f}>
                              {FORMALITY_LABELS[f]}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5 sm:col-span-2">
                      <Label>Pattern (optional)</Label>
                      <Input
                        value={draft.pattern}
                        placeholder="Solid, striped, checked…"
                        onChange={(e) => patch(draft.key, { pattern: e.target.value })}
                      />
                    </div>
                  </div>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setDrafts((list) => list.filter((d) => d.key !== draft.key))
                    }
                  >
                    <Trash2 className="mr-2 h-3.5 w-3.5" /> Discard
                  </Button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-7">
            <Button
              variant="accent"
              size="lg"
              onClick={saveAll}
              disabled={saving || drafts.some((d) => d.tagging)}
            >
              {saving ? "Saving…" : `Confirm & save ${drafts.length} piece${drafts.length > 1 ? "s" : ""}`}
            </Button>
          </div>
        </>
      )}
    </AppShell>
  );
}
