import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { ArrowRight, Check, RefreshCw, Sparkles, Wand2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DEMO_ITEMS, DEMO_WEEK } from "@/lib/demo-data";
import { buildOutfit } from "@/lib/outfit";
import {
  CATEGORY_LABELS,
  FORMALITY_LABELS,
  prettyDate,
  shortDay,
  todayISO,
  weekdaysOf,
  type ClosetItem,
} from "@/lib/wardrobe";

export const Route = createFileRoute("/demo")({
  head: () => ({
    meta: [
      { title: "Live Demo — Suited Sync" },
      {
        name: "description",
        content:
          "Explore Suited Sync with a sample wardrobe: one considered outfit per day, a week at a glance, and the AI Mirror try-on flow. No signup required.",
      },
      { property: "og:title", content: "Live Demo — Suited Sync" },
      {
        property: "og:description",
        content:
          "Try the Suited Sync wardrobe planner with a pre-seeded sample closet — no account needed.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "index, follow" },
    ],
  }),
  component: DemoPage,
});

/** Every write / paid / external action in demo mode routes here. */
function demoAction() {
  toast("This is a demo — sign up to use this for real.");
}

function DemoTile({ item, large }: { item: ClosetItem; large?: boolean }) {
  return (
    <figure className="space-y-2">
      <div
        className={`relative overflow-hidden rounded-sm border border-border/60 ${
          large ? "aspect-[3/4]" : "aspect-[3/4]"
        }`}
        style={{ backgroundColor: item.color_hex ?? "#1a1a1a" }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-white/10" />
        <span className="absolute bottom-2 left-2 text-[0.55rem] uppercase tracking-[0.18em] text-white/85">
          {CATEGORY_LABELS[item.category]}
        </span>
      </div>
      <figcaption className="space-y-0.5">
        <p className="truncate text-sm">{item.name}</p>
        <p className="text-[0.66rem] uppercase tracking-[0.16em] text-muted-foreground">
          {FORMALITY_LABELS[item.formality]}
          {item.color ? ` · ${item.color}` : ""}
        </p>
      </figcaption>
    </figure>
  );
}

function DemoPage() {
  const [dayIndex, setDayIndex] = useState(0);
  const [seed, setSeed] = useState(1);
  const week = weekdaysOf(todayISO());
  const day = DEMO_WEEK[dayIndex] ?? DEMO_WEEK[0]!;

  const suggestion = useMemo(
    () => buildOutfit(DEMO_ITEMS, day.formality, { seed: seed + dayIndex * 17 }),
    [day.formality, seed, dayIndex],
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 border-b border-accent/40 bg-accent/15 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-2.5 md:px-8">
          <p className="text-xs text-foreground">
            <span className="mr-2 bg-accent px-2 py-0.5 text-[0.6rem] uppercase tracking-[0.18em] text-accent-foreground">
              Demo
            </span>
            You're exploring Suited Sync with a sample closet — nothing here is saved.
          </p>
          <Button variant="accent" size="sm" asChild>
            <a href="/auth" target="_top" rel="noopener">
              Sign up free <ArrowRight className="ml-2 h-3.5 w-3.5" />
            </a>
          </Button>
        </div>
      </div>

      <header className="border-b border-border/70">
        <div className="mx-auto flex max-w-6xl items-center gap-2 px-5 py-4 md:px-8">
          <Sparkles className="h-4 w-4 text-accent" />
          <span className="font-display text-xl leading-none tracking-tight">Suited Sync</span>
          <span className="ml-auto text-[0.7rem] uppercase tracking-[0.18em] text-muted-foreground">
            Sample wardrobe · {DEMO_ITEMS.length} pieces
          </span>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-24 pt-8 md:px-8">
        <section>
          <p className="text-[0.7rem] uppercase tracking-[0.2em] text-accent">
            {prettyDate(week[dayIndex] ?? todayISO())}
          </p>
          <h1 className="mt-2 font-display text-4xl tracking-tight md:text-5xl">{day.label}</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Inferred dress code · {FORMALITY_LABELS[day.formality]}
          </p>
        </section>

        <section className="mt-6 flex gap-2 overflow-x-auto pb-1">
          {DEMO_WEEK.map((entry, index) => (
            <button
              key={entry.label}
              type="button"
              onClick={() => setDayIndex(index)}
              className={`min-w-[7.5rem] border px-3 py-2 text-left transition-colors ${
                index === dayIndex
                  ? "border-accent bg-accent/10"
                  : "border-border/70 hover:border-foreground/40"
              }`}
            >
              <span className="block text-[0.62rem] uppercase tracking-[0.18em] text-muted-foreground">
                {shortDay(week[index] ?? todayISO())}
              </span>
              <span className="mt-1 block truncate text-xs">{entry.label}</span>
            </button>
          ))}
        </section>

        <section className="mt-10 animate-fade-up">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {suggestion.items.map((item) => (
              <DemoTile key={item.id} item={item} large />
            ))}
          </div>

          {suggestion.rationale && (
            <p className="mt-5 border-l-2 border-accent pl-3 text-sm leading-relaxed text-muted-foreground">
              <span className="text-[0.66rem] uppercase tracking-[0.18em] text-accent">
                Why this
              </span>
              <br />
              {suggestion.rationale}
            </p>
          )}

          <div className="mt-6 flex flex-wrap items-center gap-2">
            <Button variant="accent" onClick={demoAction}>
              <Wand2 className="mr-2 h-4 w-4" /> Preview on Me
            </Button>
            <Button variant="outline" onClick={() => setSeed((s) => s + 1)}>
              <RefreshCw className="mr-2 h-4 w-4" /> Regenerate
            </Button>
            <Button variant="ghost" onClick={demoAction}>
              <Check className="mr-2 h-4 w-4" /> Mark as worn
            </Button>
          </div>
        </section>

        <section className="mt-16">
          <h2 className="font-display text-2xl tracking-tight">The sample closet</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Every suggestion is built only from these pieces — the real app tags your own photos
            automatically.
          </p>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {DEMO_ITEMS.map((item) => (
              <DemoTile key={item.id} item={item} />
            ))}
          </div>
        </section>

        <section className="mt-16 border border-border/70 p-6 text-center md:p-10">
          <h2 className="font-display text-3xl tracking-tight">Dress your own closet</h2>
          <p className="mx-auto mt-2 max-w-xl text-sm text-muted-foreground">
            Photograph your wardrobe once, connect your calendar, and get one considered outfit every
            morning — with an AI Mirror try-on before you commit.
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <Button variant="accent" asChild>
              <a href="/auth" target="_top" rel="noopener">
                Create your account
              </a>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/">Back to the app</Link>
            </Button>
          </div>
        </section>
      </main>
    </div>
  );
}
