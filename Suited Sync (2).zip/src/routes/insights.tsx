import { createFileRoute, Link } from "@tanstack/react-router";
import { Lock } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { subscriptionIsActive, useSubscription } from "@/lib/billing";
import { useAuth } from "@/lib/useAuth";
import { useCloset } from "@/lib/queries";
import { useFunnel } from "@/lib/analytics";
import {
  CATEGORIES,
  CATEGORY_LABELS,
  FORMALITIES,
  FORMALITY_LABELS,
  availabilityOf,
  type Category,
  type Formality,
} from "@/lib/wardrobe";

export const Route = createFileRoute("/insights")({
  head: () => ({
    meta: [
      { title: "Wardrobe Insights — Suited Sync" },
      {
        name: "description",
        content:
          "See how your closet is distributed across categories and dress codes, and where combinations fall short.",
      },
      { property: "og:title", content: "Wardrobe Insights — Suited Sync" },
      {
        property: "og:description",
        content: "An informational look at the balance of your wardrobe.",
      },
    ],
  }),
  component: InsightsPage,
});

function InsightsPage() {
  const { userId } = useAuth();
  const subscription = useSubscription(userId);
  const isPro = subscriptionIsActive(subscription.data);
  const closet = useCloset(userId);
  const funnel = useFunnel(userId);
  const items = closet.data ?? [];
  const counts = funnel.data ?? {};
  const unavailable = items.filter((i) => availabilityOf(i) !== "available");

  const FUNNEL_STEPS: { name: string; label: string }[] = [
    { name: "item_added", label: "Intake batches saved" },
    { name: "tag_corrected", label: "Tags corrected" },
    { name: "outfit_regenerated", label: "Outfits regenerated" },
    { name: "outfit_marked_worn", label: "Outfits worn" },
    { name: "preview_requested", label: "Previews requested" },
    { name: "preview_generated", label: "Previews generated" },
    { name: "preview_failed", label: "Previews failed" },
    { name: "portfolio_added", label: "Added to portfolio" },
  ];

  const count = (category: Category, formality?: Formality) =>
    items.filter((i) => i.category === category && (!formality || i.formality === formality)).length;

  const gaps: string[] = [];
  for (const formality of FORMALITIES) {
    const tops = count("top", formality);
    const bottoms = count("bottom", formality);
    const dresses = count("dress", formality);
    const shoes = count("shoes", formality);
    const label = FORMALITY_LABELS[formality].toLowerCase();

    if (tops === 0 && dresses === 0) {
      gaps.push(`No ${label} tops or dresses — days at this dress code can't be styled yet.`);
    } else if (tops >= 3 && bottoms === 0 && dresses === 0) {
      gaps.push(`${tops} ${label} tops but no matching bottoms.`);
    } else if (bottoms >= 3 && tops === 0) {
      gaps.push(`${bottoms} ${label} bottoms but no matching tops.`);
    } else if (tops >= 4 && bottoms === 1) {
      gaps.push(`${tops} ${label} tops rotating against a single bottom.`);
    }
    if (shoes === 0 && (tops > 0 || dresses > 0)) {
      gaps.push(`No ${label} shoes to finish these looks.`);
    }
  }

  if (!userId) {
    return (
      <AppShell backdrop>
        <p className="text-sm text-muted-foreground">Sign in to see your wardrobe insights.</p>
      </AppShell>
    );
  }

  return (
    <AppShell backdrop>
      <header className="max-w-xl">
        <p className="text-[0.7rem] uppercase tracking-[0.28em] text-accent">Gap analysis</p>
        <h1 className="mt-2 font-display text-4xl leading-tight">Wardrobe insights</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          A read on how your closet is balanced. Informational only — no shopping suggestions.
        </p>
      </header>

      {!subscription.isLoading && !isPro && (
        <section className="mt-10 max-w-xl rounded-sm border border-accent/40 bg-accent/10 p-5">
          <p className="flex items-center gap-1.5 text-[0.66rem] uppercase tracking-[0.18em] text-accent">
            <Lock className="h-3 w-3" /> Pro feature
          </p>
          <h2 className="mt-2 font-display text-2xl leading-tight">
            Gap analysis is part of Pro
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Pro includes wardrobe gap insights and 25 AI Mirror previews a month for $9.99.
          </p>
          <Button variant="accent" size="sm" className="mt-4" asChild>
            <Link to="/billing">See plans</Link>
          </Button>
        </section>
      )}

      {isPro && (
      <section className="mt-10 overflow-x-auto">
        <table className="w-full min-w-[36rem] border-collapse text-sm">
          <thead>
            <tr className="border-b border-border">
              <th className="py-3 text-left text-[0.66rem] font-normal uppercase tracking-[0.18em] text-muted-foreground">
                Category
              </th>
              {FORMALITIES.map((f) => (
                <th
                  key={f}
                  className="py-3 text-right text-[0.66rem] font-normal uppercase tracking-[0.18em] text-muted-foreground"
                >
                  {FORMALITY_LABELS[f]}
                </th>
              ))}
              <th className="py-3 text-right text-[0.66rem] font-normal uppercase tracking-[0.18em] text-muted-foreground">
                Total
              </th>
            </tr>
          </thead>
          <tbody>
            {CATEGORIES.map((c) => (
              <tr key={c} className="border-b border-border/60">
                <td className="py-3">{CATEGORY_LABELS[c]}</td>
                {FORMALITIES.map((f) => (
                  <td
                    key={f}
                    className={`py-3 text-right tabular-nums ${
                      count(c, f) === 0 ? "text-muted-foreground/50" : ""
                    }`}
                  >
                    {count(c, f)}
                  </td>
                ))}
                <td className="py-3 text-right font-medium tabular-nums">{count(c)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      )}

      {isPro && (
      <section className="mt-12 max-w-2xl">
        <h2 className="font-display text-2xl">Where it gets thin</h2>
        {items.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">
            Add pieces to your closet and this will fill in.
          </p>
        ) : gaps.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">
            Nothing obviously unbalanced — every dress code you own has a workable combination.
          </p>
        ) : (
          <ul className="mt-4 space-y-2">
            {gaps.map((gap) => (
              <li key={gap} className="border-l-2 border-accent pl-3 text-sm leading-relaxed">
                {gap}
              </li>
            ))}
          </ul>
        )}
      </section>
      )}

      {isPro && (
        <section className="mt-12 max-w-2xl">
          <h2 className="font-display text-2xl">Out of rotation</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            {unavailable.length === 0
              ? "Everything in your closet is currently wearable."
              : `${unavailable.length} piece${unavailable.length === 1 ? " is" : "s are"} in the laundry or packed away and won't be suggested until you bring ${unavailable.length === 1 ? "it" : "them"} back.`}
          </p>
        </section>
      )}

      {isPro && (
        <section className="mt-12 max-w-2xl">
          <h2 className="font-display text-2xl">Your usage</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            How you actually move through the app — intake, styling, then try-on.
          </p>
          <dl className="mt-4 grid grid-cols-2 gap-x-8 gap-y-2 text-sm sm:grid-cols-3">
            {FUNNEL_STEPS.map((step) => (
              <div key={step.name} className="border-b border-border/60 py-2">
                <dt className="text-[0.62rem] uppercase tracking-[0.16em] text-muted-foreground">
                  {step.label}
                </dt>
                <dd className="mt-1 font-display text-2xl tabular-nums">
                  {counts[step.name] ?? 0}
                </dd>
              </div>
            ))}
          </dl>
        </section>
      )}
    </AppShell>
  );
}
