import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { z } from "zod";
import { CreditCard, ExternalLink, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { MirrorPackCheckout } from "@/components/MirrorPackCheckout";
import { MIRROR_PACK_PRICE_ID, paymentsConfigured } from "@/lib/stripe";
import {
  PRO_PRICE_ID,
  PRO_PRICE_LABEL,
  formatMoney,
  subscriptionIsActive,
  useBillingPortal,
  useEntitlement,
  usePurchases,
  useSubscription,
} from "@/lib/billing";
import { useAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/billing")({
  validateSearch: z.object({ purchase: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Membership & Billing — Suited Sync" },
      {
        name: "description",
        content:
          "Manage your Suited Sync Pro membership, AI Mirror preview allowance, extra packs and payment receipts.",
      },
      { property: "og:title", content: "Membership & Billing — Suited Sync" },
      {
        property: "og:description",
        content: "Your plan, preview allowance and purchase history in one place.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BillingPage,
});

function BillingPage() {
  const { purchase } = Route.useSearch();
  const { userId } = useAuth();
  const qc = useQueryClient();
  const subscription = useSubscription(userId);
  const purchases = usePurchases(userId);
  const [awaiting, setAwaiting] = useState(purchase === "complete");
  const entitlement = useEntitlement(userId, awaiting ? { refetchInterval: 2000 } : undefined);
  const portal = useBillingPortal();
  const [open, setOpen] = useState<null | "pro" | "pack">(null);

  const active = subscriptionIsActive(subscription.data);
  const ent = entitlement.data;

  // After returning from checkout, poll briefly until the webhook lands.
  useEffect(() => {
    if (!awaiting) return;
    setOpen(null);
    const timer = setTimeout(() => setAwaiting(false), 30000);
    return () => clearTimeout(timer);
  }, [awaiting]);

  useEffect(() => {
    if (!awaiting) return;
    if (active || (ent && ent.pack_balance > 0)) {
      setAwaiting(false);
      toast.success("Payment confirmed — your account is updated.");
      qc.invalidateQueries({ queryKey: ["subscription"] });
      qc.invalidateQueries({ queryKey: ["purchases"] });
      qc.invalidateQueries({ queryKey: ["profile"] });
    }
  }, [awaiting, active, ent, qc]);

  useEffect(() => {
    if (awaiting) {
      subscription.refetch();
      purchases.refetch();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [awaiting, ent?.pack_balance]);

  if (!userId) {
    return (
      <AppShell backdrop>
        <p className="text-sm text-muted-foreground">
          <Link to="/auth" className="underline underline-offset-4">
            Sign in
          </Link>{" "}
          to manage your membership.
        </p>
      </AppShell>
    );
  }

  const renewal = subscription.data?.current_period_end
    ? new Date(subscription.data.current_period_end).toLocaleDateString(undefined, {
        month: "long",
        day: "numeric",
        year: "numeric",
      })
    : null;

  return (
    <AppShell backdrop>
      <header className="max-w-xl">
        <p className="flex items-center gap-1.5 text-[0.7rem] uppercase tracking-[0.28em] text-accent">
          <CreditCard className="h-3 w-3" /> Membership
        </p>
        <h1 className="mt-2 font-display text-4xl leading-tight">Billing</h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Outfit planning, your closet, the portfolio and calendar sync are always free. Pro adds AI
          Mirror previews and wardrobe gap insights.
        </p>
      </header>

      {awaiting && (
        <p className="mt-6 rounded-sm border border-accent/40 bg-accent/10 px-4 py-3 text-xs">
          Confirming your payment… this usually takes a few seconds.
        </p>
      )}

      <div className="mt-10 grid gap-10 md:grid-cols-2">
        <section className="rounded-sm border border-border p-5">
          <p className="text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
            Current plan
          </p>
          <h2 className="mt-2 font-display text-3xl">
            {active ? "Suited Sync Pro" : "Free"}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {active ? PRO_PRICE_LABEL : "No charge"}
          </p>

          {ent && (
            <div className="mt-5 space-y-1 text-sm">
              <p>
                {ent.used} of {ent.monthly_quota} monthly AI Mirror previews used
              </p>
              <p className="text-muted-foreground">
                {ent.pack_balance} purchased preview{ent.pack_balance === 1 ? "" : "s"} in reserve
                (these never expire)
              </p>
              <p className="text-muted-foreground">{ent.remaining} available right now</p>
            </div>
          )}

          {active && subscription.data && (
            <p className="mt-5 text-xs text-muted-foreground">
              Status: {subscription.data.status}
              {renewal
                ? subscription.data.cancel_at_period_end
                  ? ` — access ends ${renewal}`
                  : ` — renews ${renewal}`
                : ""}
            </p>
          )}

          <div className="mt-6 flex flex-wrap gap-2">
            {!paymentsConfigured() ? (
              <p className="text-xs text-muted-foreground">
                Checkout is not configured for this build yet.
              </p>
            ) : active ? (
              <Button
                variant="outline"
                size="sm"
                disabled={portal.isPending}
                onClick={() =>
                  portal.mutate(undefined, {
                    onError: (error) => toast.error(error.message),
                  })
                }
              >
                <ExternalLink className="mr-2 h-3.5 w-3.5" /> Manage or cancel
              </Button>
            ) : (
              <Button variant="accent" size="sm" onClick={() => setOpen("pro")}>
                <Sparkles className="mr-2 h-3.5 w-3.5" /> Go Pro — {PRO_PRICE_LABEL}
              </Button>
            )}
            {paymentsConfigured() && (
              <Button variant="ghost" size="sm" onClick={() => setOpen("pack")}>
                Buy 10 extra previews — $4.99
              </Button>
            )}
          </div>

          {open && (
            <>
              <MirrorPackCheckout
                priceId={open === "pro" ? PRO_PRICE_ID : MIRROR_PACK_PRICE_ID}
                returnUrl={`${window.location.origin}/billing?purchase=complete`}
              />
              <Button variant="ghost" size="sm" className="mt-3" onClick={() => setOpen(null)}>
                Cancel
              </Button>
            </>
          )}
        </section>

        <section>
          <h2 className="font-display text-2xl">What Pro includes</h2>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>25 AI Mirror try-on previews every month</li>
            <li>Wardrobe gap insights</li>
            <li>Extra packs of 10 previews at $4.99, never expiring</li>
          </ul>
          <p className="mt-4 text-xs text-muted-foreground">
            On the free plan you still get 3 AI Mirror previews a month, plus unlimited outfit
            planning and calendar sync.
          </p>

          <h2 className="mt-10 font-display text-2xl">Purchase history</h2>
          {purchases.data?.length ? (
            <ul className="mt-4 divide-y divide-border/70 text-sm">
              {purchases.data.map((p) => (
                <li key={p.id} className="flex items-center justify-between py-2.5">
                  <span>
                    {p.previews_granted} previews
                    <span className="ml-2 text-xs text-muted-foreground">
                      {new Date(p.created_at).toLocaleDateString()}
                    </span>
                  </span>
                  <span>{formatMoney(p.amount_total, p.currency)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-4 text-sm text-muted-foreground">No purchases yet.</p>
          )}
          <p className="mt-4 text-xs text-muted-foreground">
            Receipts and invoices are emailed automatically and are also available in the billing
            portal.
          </p>
        </section>
      </div>
    </AppShell>
  );
}
