import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { PhotoFrame } from "@/components/PhotoFrame";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/useAuth";
import { useCloset, useDeleteItem, useSaveItem } from "@/lib/queries";
import {
  AVAILABILITIES,
  AVAILABILITY_LABELS,
  CATEGORIES,
  CATEGORY_LABELS,
  FORMALITIES,
  FORMALITY_LABELS,
  availabilityOf,
  prettyDate,
  type Availability,
  type Category,
  type Formality,
} from "@/lib/wardrobe";

export const Route = createFileRoute("/closet/$itemId")({
  head: () => ({
    meta: [
      { title: "Closet piece — Suited Sync" },
      {
        name: "description",
        content: "Review a garment's photo, tags and last-worn date, or edit and remove it.",
      },
      { property: "og:title", content: "Closet piece — Suited Sync" },
      {
        property: "og:description",
        content: "Review a garment's photo, tags and last-worn date.",
      },
    ],
  }),
  component: ItemDetail,
});

function ItemDetail() {
  const { itemId } = Route.useParams();
  const { userId } = useAuth();
  const navigate = useNavigate();
  const closet = useCloset(userId);
  const save = useSaveItem();
  const remove = useDeleteItem();

  const item = (closet.data ?? []).find((i) => i.id === itemId);
  const [form, setForm] = useState({
    name: "",
    color: "",
    pattern: "",
    brand: "",
    category: "top" as Category,
    formality: "business_casual" as Formality,
    availability: "available" as Availability,
  });

  useEffect(() => {
    if (!item) return;
    setForm({
      name: item.name ?? "",
      color: item.color ?? "",
      pattern: item.pattern ?? "",
      brand: item.brand ?? "",
      category: item.category,
      formality: item.formality,
      availability: availabilityOf(item),
    });
  }, [item]);

  if (!userId) {
    return (
      <AppShell backdrop="closet">
        <p className="text-sm text-muted-foreground">Sign in to view this piece.</p>
      </AppShell>
    );
  }

  if (!item) {
    return (
      <AppShell backdrop="closet">
        <p className="text-sm text-muted-foreground">
          {closet.isLoading ? "Loading…" : "That piece is no longer in your closet."}
        </p>
      </AppShell>
    );
  }

  return (
    <AppShell backdrop="closet">
      <Link
        to="/closet"
        className="inline-flex items-center gap-1.5 text-[0.7rem] uppercase tracking-[0.18em] text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-3 w-3" /> Closet
      </Link>

      <div className="mt-6 grid gap-10 md:grid-cols-2">
        <PhotoFrame
          path={item.photo_url}
          alt={item.name || CATEGORY_LABELS[item.category]}
          className="aspect-[3/4] rounded-sm"
          fallbackLabel={CATEGORY_LABELS[item.category]}
        />

        <div>
          <h1 className="font-display text-4xl leading-tight">
            {item.name || CATEGORY_LABELS[item.category]}
          </h1>
          <p className="mt-2 text-[0.68rem] uppercase tracking-[0.18em] text-muted-foreground">
            {item.last_worn_date
              ? `Last worn ${prettyDate(item.last_worn_date)}`
              : "Not worn yet"}
            {item.auto_tagged ? " · auto-tagged" : ""}
          </p>

          <div className="mt-7 grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Name</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Colour</Label>
              <Input
                value={form.color}
                onChange={(e) => setForm({ ...form, color: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select
                value={form.category}
                onValueChange={(v) => setForm({ ...form, category: v as Category })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {CATEGORY_LABELS[c]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Formality</Label>
              <Select
                value={form.formality}
                onValueChange={(v) => setForm({ ...form, formality: v as Formality })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FORMALITIES.map((f) => (
                    <SelectItem key={f} value={f}>
                      {FORMALITY_LABELS[f]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Pattern</Label>
              <Input
                value={form.pattern}
                onChange={(e) => setForm({ ...form, pattern: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Brand</Label>
              <Input
                value={form.brand}
                onChange={(e) => setForm({ ...form, brand: e.target.value })}
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Availability</Label>
              <Select
                value={form.availability}
                onValueChange={(v) => setForm({ ...form, availability: v as Availability })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {AVAILABILITIES.map((a) => (
                    <SelectItem key={a} value={a}>
                      {AVAILABILITY_LABELS[a]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                Pieces in the laundry or packed away are never suggested until you bring them back.
              </p>
            </div>
          </div>

          <div className="mt-7 flex flex-wrap gap-2">
            <Button
              variant="accent"
              onClick={async () => {
                await save.mutateAsync({
                  id: item.id,
                  name: form.name.trim() || CATEGORY_LABELS[form.category],
                  color: form.color.trim() || null,
                  pattern: form.pattern.trim() || null,
                  brand: form.brand.trim() || null,
                  category: form.category,
                  formality: form.formality,
                  availability: form.availability,
                  tags_confirmed: true,
                });
                toast.success("Piece updated.");
              }}
            >
              Save changes
            </Button>
            <Button
              variant="ghost"
              onClick={async () => {
                await remove.mutateAsync(item.id);
                toast.success("Removed from your closet.");
                navigate({ to: "/closet" });
              }}
            >
              <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
