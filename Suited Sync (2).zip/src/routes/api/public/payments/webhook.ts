import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { type StripeEnv, createStripeClient, verifyWebhook } from "@/lib/stripe.server";

const PREVIEWS_PER_PACK = 10;
const PACK_PRICE_ID = "mirror_pack_10";

function getSupabase() {
  return createClient(
    process.env["SUPABASE_URL"]!,
    process.env["SUPABASE_SERVICE_ROLE_KEY"]!,
  );
}

function readPriceId(item: any): string | null {
  return (
    item?.price?.lookup_key ??
    item?.price?.metadata?.lovable_external_id ??
    item?.price?.id ??
    null
  );
}

async function grantMirrorPack(session: any, env: StripeEnv) {
  const userId = session.metadata?.userId as string | undefined;
  const priceId = session.metadata?.priceId as string | undefined;
  if (!userId || priceId !== PACK_PRICE_ID) return;

  const supabase = getSupabase();
  let quantity = 1;
  try {
    const stripe = createStripeClient(env);
    const lineItems = await stripe.checkout.sessions.listLineItems(session.id, { limit: 1 });
    quantity = lineItems.data[0]?.quantity ?? 1;
  } catch (error) {
    console.error("[payments] could not read line items, defaulting to 1 pack:", error);
  }

  // Unique constraint on stripe_session_id keeps webhook retries idempotent.
  const { error } = await supabase.from("mirror_pack_purchases").insert({
    user_id: userId,
    stripe_session_id: session.id,
    quantity,
    previews_granted: PREVIEWS_PER_PACK * quantity,
    amount_total: session.amount_total ?? null,
    currency: session.currency ?? null,
    environment: env,
  });
  if (error) {
    if (error.code === "23505") return; // already granted
    console.error("[payments] could not record purchase:", error.message);
    return;
  }

  const { error: grantError } = await supabase.rpc("grant_mirror_pack", {
    p_user: userId,
    p_previews: PREVIEWS_PER_PACK * quantity,
  });
  if (grantError) console.error("[payments] could not grant previews:", grantError.message);
}

/** A refunded pack loses the previews it bought (never below zero). */
async function revokeRefundedPack(charge: any, env: StripeEnv) {
  const paymentIntent =
    typeof charge.payment_intent === "string" ? charge.payment_intent : charge.payment_intent?.id;
  if (!paymentIntent) return;

  const stripe = createStripeClient(env);
  const sessions = await stripe.checkout.sessions.list({ payment_intent: paymentIntent, limit: 1 });
  const sessionId = sessions.data[0]?.id;
  if (!sessionId) return;

  const supabase = getSupabase();
  const { data: purchase } = await supabase
    .from("mirror_pack_purchases")
    .select("user_id, previews_granted")
    .eq("stripe_session_id", sessionId)
    .eq("environment", env)
    .maybeSingle();
  if (!purchase) return;

  const row = purchase as { user_id: string; previews_granted: number };
  await supabase.rpc("grant_mirror_pack", {
    p_user: row.user_id,
    p_previews: -row.previews_granted,
  });
}

async function upsertSubscription(subscription: any, env: StripeEnv) {
  const userId = subscription.metadata?.userId as string | undefined;
  const item = subscription.items?.data?.[0];
  const periodStart = item?.current_period_start ?? subscription.current_period_start;
  const periodEnd = item?.current_period_end ?? subscription.current_period_end;

  const row = {
    stripe_subscription_id: subscription.id,
    stripe_customer_id:
      typeof subscription.customer === "string" ? subscription.customer : subscription.customer?.id,
    product_id: typeof item?.price?.product === "string" ? item.price.product : null,
    price_id: readPriceId(item),
    status: subscription.status,
    current_period_start: periodStart ? new Date(periodStart * 1000).toISOString() : null,
    current_period_end: periodEnd ? new Date(periodEnd * 1000).toISOString() : null,
    cancel_at_period_end: subscription.cancel_at_period_end ?? false,
    environment: env,
    updated_at: new Date().toISOString(),
  };

  const supabase = getSupabase();
  if (userId) {
    const { error } = await supabase
      .from("subscriptions")
      .upsert({ ...row, user_id: userId }, { onConflict: "stripe_subscription_id" });
    if (error) console.error("[payments] could not upsert subscription:", error.message);
    return;
  }

  // No metadata (e.g. plan changed from the billing portal) — update in place.
  const { error } = await supabase
    .from("subscriptions")
    .update(row)
    .eq("stripe_subscription_id", subscription.id)
    .eq("environment", env);
  if (error) console.error("[payments] could not update subscription:", error.message);
}

async function markSubscriptionCanceled(subscription: any, env: StripeEnv) {
  const supabase = getSupabase();
  await supabase
    .from("subscriptions")
    .update({ status: "canceled", updated_at: new Date().toISOString() })
    .eq("stripe_subscription_id", subscription.id)
    .eq("environment", env);
}

async function handleWebhook(request: Request, env: StripeEnv) {
  const event = await verifyWebhook(request, env);

  switch (event.type) {
    case "checkout.session.completed": {
      const session = event.data.object;
      if (session.payment_status !== "unpaid") await grantMirrorPack(session, env);
      break;
    }
    case "checkout.session.async_payment_succeeded":
      await grantMirrorPack(event.data.object, env);
      break;
    case "checkout.session.async_payment_failed":
    case "checkout.session.expired":
      console.log("[payments] checkout not completed:", event.type, event.data.object?.id);
      break;
    case "customer.subscription.created":
    case "customer.subscription.updated":
      await upsertSubscription(event.data.object, env);
      break;
    case "customer.subscription.deleted":
      await markSubscriptionCanceled(event.data.object, env);
      break;
    case "charge.refunded":
      await revokeRefundedPack(event.data.object, env);
      break;
    case "invoice.paid":
    case "invoice.payment_failed":
      // Subscription state is carried by the customer.subscription.* events.
      console.log("[payments] invoice event:", event.type);
      break;
    default:
      console.log("[payments] unhandled event:", event.type);
  }
}

export const Route = createFileRoute("/api/public/payments/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rawEnv = new URL(request.url).searchParams.get("env");
        if (rawEnv !== "sandbox" && rawEnv !== "live") {
          console.error("[payments] invalid env query parameter:", rawEnv);
          return Response.json({ received: true, ignored: "invalid env" });
        }
        try {
          await handleWebhook(request, rawEnv);
          return Response.json({ received: true });
        } catch (error) {
          console.error("[payments] webhook error:", error);
          return new Response("Webhook error", { status: 400 });
        }
      },
    },
  },
});
