import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Camera, CalendarDays, Check, Shirt } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useCloset, useProfile } from "@/lib/queries";
import { useAuth } from "@/lib/useAuth";

export const Route = createFileRoute("/welcome")({
  head: () => ({
    meta: [
      { title: "Get started — Suited Sync" },
      {
        name: "description",
        content:
          "Three quick steps to set up Suited Sync: photograph your closet, add a reference photo and connect your calendar.",
      },
      { property: "og:title", content: "Get started — Suited Sync" },
      {
        property: "og:description",
        content: "Set up your closet, reference photo and calendar in three steps.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: WelcomePage,
});

function WelcomePage() {
  const { userId } = useAuth();
  const profile = useProfile(userId);
  const closet = useCloset(userId);
  const router = useRouter();
  const qc = useQueryClient();

  const finish = async () => {
    if (userId) await supabase.from("profiles").update({ onboarded: true }).eq("id", userId);
    qc.invalidateQueries({ queryKey: ["profile"] });
    router.navigate({ to: "/" });
  };

  const itemCount = closet.data?.length ?? 0;
  const steps = [
    {
      icon: Shirt,
      title: "Photograph a few pieces",
      body: "Upload tops, bottoms, shoes — individually or in batches. Each one is auto-tagged and you confirm the tags.",
      done: itemCount >= 3,
      cta: { to: "/add", label: itemCount ? "Add more items" : "Add items" },
      note: (itemCount ? `${itemCount} item${itemCount === 1 ? "" : "s"} in your closet` : undefined) as string | undefined,
    },
    {
      icon: Camera,
      title: "Add a reference photo (optional)",
      body: "One front-facing, full-body photo unlocks AI Mirror try-on previews. Stored privately, never shared.",
      done: !!profile.data?.reference_photo_url,
      cta: { to: "/settings", label: "Open settings" },
      note: undefined as string | undefined,
    },
    {
      icon: CalendarDays,
      title: "Connect your calendar (optional)",
      body: "Suited Sync reads event titles to infer each day's dress code. You can always set it by hand instead.",
      done: !!profile.data?.calendar_connected,
      cta: { to: "/settings", label: "Calendar settings" },
      note: undefined as string | undefined,
    },
  ] as const;

  if (!userId) {
    return (
      <AppShell>
        <p className="text-sm text-muted-foreground">
          <Link to="/auth" className="underline underline-offset-4">
            Sign in
          </Link>{" "}
          to get started.
        </p>
      </AppShell>
    );
  }

  return (
    <AppShell backdrop>
      <header className="max-w-xl">
        <p className="text-[0.7rem] uppercase tracking-[0.28em] text-accent">Welcome</p>
        <h1 className="mt-2 font-display text-4xl leading-tight">
          Let's set up your wardrobe
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Only the first step is required — outfit suggestions come entirely from pieces you own.
        </p>
      </header>

      <ol className="mt-10 grid gap-4 md:grid-cols-3">
        {steps.map((step, index) => (
          <li key={step.title} className="rounded-sm border border-border bg-background/60 p-5">
            <div className="flex items-center justify-between">
              <step.icon className="h-4 w-4 text-accent" />
              {step.done ? (
                <Check className="h-4 w-4 text-accent" />
              ) : (
                <span className="text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
                  Step {index + 1}
                </span>
              )}
            </div>
            <h2 className="mt-4 font-display text-2xl leading-tight">{step.title}</h2>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.body}</p>
            {step.note && <p className="mt-2 text-xs text-accent">{step.note}</p>}
            <Button variant="outline" size="sm" className="mt-4" asChild>
              <Link to={step.cta.to}>{step.cta.label}</Link>
            </Button>
          </li>
        ))}
      </ol>

      <div className="mt-10 flex flex-wrap items-center gap-3">
        <Button variant="accent" onClick={finish}>
          {itemCount ? "Go to Today" : "Skip for now"}
        </Button>
        <Link
          to="/billing"
          className="text-xs text-muted-foreground underline-offset-4 hover:underline"
        >
          See plans
        </Link>
      </div>
    </AppShell>
  );
}
