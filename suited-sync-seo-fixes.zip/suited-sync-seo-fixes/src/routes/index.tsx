import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CalendarDays, FolderPlus, Lock } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/AppShell";
import { OutfitCard } from "@/components/OutfitCard";
import { PhotoFrame } from "@/components/PhotoFrame";
import { Button } from "@/components/ui/button";
import backdropAsset from "@/assets/lookbook-bw.jpg.asset.json";
import { correctEventMapping, inferCalendarWeek } from "@/lib/calendar.functions";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/lib/useAuth";
import {
  useAddToPortfolio,
  useCloset,
  useOutfits,
  useProfile,
  useSavePlan,
} from "@/lib/queries";

import { buildOutfit, explainOutfit } from "@/lib/outfit";
import { track } from "@/lib/analytics";
import { defaultGuessFor } from "@/lib/calendar";
import {
  CATEGORY_LABELS,
  FORMALITY_LABELS,
  comboKey,
  daysSince,
  isWearable,
  prettyDate,
  shortDay,
  todayISO,
  weekdaysOf,
  type ClosetItem,
  type Formality,
} from "@/lib/wardrobe";

export const Route = createFileRoute("/")({
  head: () => ({
    // NOTE: this route is served at suitedsync.com/ — the public root domain.
    // Logged-out visitors (ad clicks, search results, shared links) land here,
    // so the tags need to sell the product, not describe the logged-in dashboard.
    // The dashboard-specific copy previously here ("Today's Outfit...") only
    // makes sense to someone already using the app — it was overriding the
    // marketing tags from __root.tsx with the wrong content for this audience.
    meta: [
      { title: "Suited Sync — Wardrobe Styling Planner" },
      {
        name: "description",
        content:
          "Suited Sync plans daily outfits from the clothes you already own, matched to your calendar. Try it with a sample closet — no signup required.",
      },
      { property: "og:title", content: "Suited Sync — Wardrobe Styling Planner" },
      {
        property: "og:description",
        content: "Daily outfits from your own closet, matched to your calendar.",
      },
    ],
  }),
  component: TodayPage,
});

const EVENT_PRESETS: { label: string; formality: Formality }[] = [
  { label: "Board meeting", formality: "formal" },
  { label: "Client meeting", formality: "formal" },
  { label: "Presentation", formality: "formal" },
  { label: "Regular workday", formality: "business_casual" },
  { label: "Internal day", formality: "business_casual" },
  { label: "Workshop", formality: "business_casual" },
  { label: "Work from home", formality: "casual" },
  { label: "Offsite", formality: "casual" },
  { label: "Weekend", formality: "casual" },
  { label: "Workout", formality: "athletic" },
];

function TodayPage() {
  const { userId, loading } = useAuth();
  const router = useRouter();
  const [selected, setSelected] = useState(todayISO());
  const [seeds, setSeeds] = useState<Record<string, number>>({});
  const [showOptions, setShowOptions] = useState(false);

  const closet = useCloset(userId);
  const outfits = useOutfits(userId);
  const profile = useProfile(userId);
  const savePlan = useSavePlan(userId);
  const addToPortfolio = useAddToPortfolio(userId);

  // First-run members go through the three-step setup once.
  useEffect(() => {
    if (!userId || !profile.data || profile.data.onboarded) return;
    if ((closet.data?.length ?? 0) > 0) return;
    if (closet.isLoading) return;
    router.navigate({ to: "/welcome" });
  }, [userId, profile.data, closet.data, closet.isLoading, router]);



  const week = useMemo(() => weekdaysOf(selected), [selected]);
  const inferWeek = useServerFn(inferCalendarWeek);
  const recordCorrection = useServerFn(correctEventMapping);

  const calendar = useQuery({
    queryKey: ["calendar-week", week[0], week[week.length - 1]],
    enabled: !!userId,
    staleTime: 5 * 60 * 1000,
    retry: false,
    queryFn: () =>
      inferWeek({ data: { start: week[0]!, end: week[week.length - 1]! } }),
  });

  const items = closet.data ?? [];
  const byId = useMemo(() => new Map(items.map((i) => [i.id, i])), [items]);
  const cooldown = profile.data?.cooldown_days ?? 14;

  const avoid = useMemo(() => {
    const set = new Set<string>();
    for (const row of outfits.data ?? []) {
      if (row.status === "worn" && daysSince(row.outfit_date) <= cooldown) {
        set.add(comboKey(row.item_ids));
      }
    }
    return set;
  }, [outfits.data, cooldown]);

  const savedFor = (iso: string) => (outfits.data ?? []).find((o) => o.outfit_date === iso);

  const planFor = (iso: string, seedOffset = 0) => {
    const saved = savedFor(iso);
    const guess = calendar.data?.days?.[iso] ?? defaultGuessFor(iso);
    const eventLabel = saved?.event_label ?? guess.label;
    const formality = (saved?.formality ?? guess.formality) as Formality;
    const seed = (seeds[iso] ?? 0) + seedOffset;

    if (saved && saved.item_ids.length && seed === 0) {
      const stored = saved.item_ids.map((id) => byId.get(id)).filter(Boolean) as ClosetItem[];
      if (stored.length)
        return {
          eventLabel,
          formality,
          items: stored,
          missing: [] as never[],
          rationale: explainOutfit(stored, formality, cooldown, avoid.size > 0),
          unavailable: items.filter((i) => !isWearable(i)).length,
          saved,
        };
    }

    const built = buildOutfit(items, formality, {
      avoid,
      cooldownDays: cooldown,
      seed: seed + Number(iso.split("-").join("").slice(4)),
    });
    return {
      eventLabel,
      formality,
      items: built.items,
      missing: built.missing,
      rationale: built.rationale,
      unavailable: built.unavailable,
      saved,
    };
  };

  const plan = planFor(selected);
  const dayTitles = calendar.data?.titles?.[selected] ?? [];
  const hasReference = !!profile.data?.reference_photo_url;
  const mirrorUsed = profile.data?.mirror_generations_used ?? 0;
  const mirrorQuota = profile.data?.mirror_quota ?? 25;

  const persist = async (status: "suggested" | "worn") => {
    if (!userId) return null;
    return savePlan.mutateAsync({
      outfitDate: selected,
      eventLabel: plan.eventLabel,
      formality: plan.formality,
      itemIds: plan.items.map((i) => i.id),
      status,
    });
  };

  if (loading) {
    return (
      <AppShell backdrop>
        <p className="text-sm text-muted-foreground">Loading your closet…</p>
      </AppShell>
    );
  }

  if (!userId) {
    return (
      <AppShell backdrop>
        <section className="grid items-center gap-10 py-10 md:grid-cols-2 md:py-16">
          <div className="animate-fade-up">
            <p className="text-[0.7rem] uppercase tracking-[0.32em] text-accent">Suited Sync</p>
            <h1 className="mt-4 font-display text-5xl leading-[1.02] md:text-6xl">
              Your closet, laid out like a <span className="text-accent">portfolio</span>.
            </h1>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-muted-foreground">
              One considered outfit each morning — matched to the day's dress code, never repeating
              the same combination too soon, and previewed on you before you commit.
            </p>
            <div className="mt-8 flex flex-wrap gap-2">
              <Button variant="accent" size="lg" asChild>
                <a href="/auth">Get started</a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="/auth">Sign in</a>
              </Button>
            </div>
          </div>

          <div className="relative animate-fade-up">
            <div className="overflow-hidden rounded-sm border border-border shadow-lift">
              <img
                src={backdropAsset.url}
                alt="An open model portfolio book on a studio desk, in black and white"
                className="aspect-[4/3] w-full object-cover grayscale contrast-125"
              />
            </div>
            <span className="absolute -bottom-3 left-4 bg-accent px-3 py-1.5 text-[0.6rem] uppercase tracking-[0.24em] text-accent-foreground">
              Lookbook
            </span>
          </div>
        </section>
      </AppShell>
    );
  }


  return (
    <AppShell backdrop>

      <div className="space-y-12">
        <header className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-[0.7rem] uppercase tracking-[0.28em] text-accent">
              {selected === todayISO() ? "Today" : "Planned"}
            </p>
            <h1 className="mt-2 font-display text-4xl leading-tight md:text-5xl">
              {prettyDate(selected)}
            </h1>
          </div>

          <div className="min-w-56">
            <label className="mb-1.5 flex items-center gap-1.5 text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
              <CalendarDays className="h-3 w-3" />
              {calendar.data?.connected ? "Inferred from calendar" : "Event type"}
            </label>
            <Select
              value={plan.eventLabel}
              onValueChange={(label) => {
                const preset = EVENT_PRESETS.find((p) => p.label === label);
                if (!preset || !userId) return;
                savePlan.mutate({
                  outfitDate: selected,
                  eventLabel: preset.label,
                  formality: preset.formality,
                  itemIds: [],
                  status: "suggested",
                });
                setSeeds((s) => ({ ...s, [selected]: (s[selected] ?? 0) + 1 }));
                const source = dayTitles[0];
                if (source) {
                  recordCorrection({
                    data: {
                      keyword: source.trim().slice(0, 60),
                      eventLabel: preset.label,
                      formality: preset.formality,
                    },
                  }).catch(() => undefined);
                }
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {EVENT_PRESETS.map((p) => (
                  <SelectItem key={p.label} value={p.label}>
                    {p.label} · {FORMALITY_LABELS[p.formality]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {dayTitles.length > 0 && (
              <p className="mt-1.5 truncate text-[0.66rem] text-muted-foreground">
                {dayTitles.slice(0, 2).join(" · ")}
              </p>
            )}
          </div>
        </header>


        <section>
          <div className="mb-5 flex items-baseline justify-between">
            <h2 className="font-display text-2xl">
              {FORMALITY_LABELS[plan.formality]} — your look
            </h2>
            <span className="text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
              AI Mirror {mirrorUsed}/{mirrorQuota} this month
            </span>
          </div>

          {items.length === 0 ? (
            <div className="rounded-sm border border-dashed border-border p-10 text-center">
              <p className="font-display text-2xl">Your closet is empty</p>
              <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
                Photograph a few pieces and Suited Sync will only ever style you in clothes you
                actually own.
              </p>
              <Button variant="accent" className="mt-6" asChild>
                <a href="/add">Add your first pieces</a>
              </Button>
            </div>
          ) : (
            <OutfitCard
              items={plan.items}
              missing={plan.missing}
              rationale={plan.rationale}
              unavailable={plan.unavailable}
              worn={plan.saved?.status === "worn"}
              mirrorEnabled={hasReference}
              {...(hasReference
                ? {}
                : {
                    mirrorHint:
                      "Add a full-body reference photo in Settings to unlock AI Mirror.",
                  })}
              onRegenerate={() => {
                track(userId, "outfit_regenerated", { date: selected });
                setSeeds((s) => ({ ...s, [selected]: (s[selected] ?? 0) + 1 }));
              }}
              onMarkWorn={async () => {
                await persist("worn");
                track(userId, "outfit_marked_worn", { date: selected });
                toast.success(`Marked as worn — resting this combination for ${cooldown} days.`);
              }}
              onPreview={async () => {
                await persist("suggested");
                window.location.href = `/mirror?date=${selected}`;
              }}
            />

          )}

          {items.length > 0 && (
            <div className="mt-5">
              <Button
                variant="outline"
                size="sm"
                disabled={addToPortfolio.isPending}
                onClick={async () => {
                  await persist("suggested");
                  await addToPortfolio.mutateAsync({
                    kind: "look",
                    title: `${plan.eventLabel} — ${prettyDate(selected)}`,
                    eventLabel: plan.eventLabel,
                    formality: plan.formality,
                    itemIds: plan.items.map((i) => i.id),
                  });
                  track(userId, "portfolio_added", { kind: "look", date: selected });
                  toast.success("Look added to your model portfolio.");
                }}
              >
                <FolderPlus className="mr-2 h-3.5 w-3.5" /> Add look to portfolio
              </Button>
            </div>
          )}



          {items.length > 0 && (
            <div className="mt-8 border-t border-border/70 pt-6">
              <Button variant="ghost" size="sm" onClick={() => setShowOptions((v) => !v)}>
                {showOptions ? "Hide other options" : "See other options"}
              </Button>
              {showOptions && (
                <div className="mt-5 grid gap-6 md:grid-cols-2">
                  {[1, 2].map((offset) => {
                    const alt = planFor(selected, offset * 37);
                    return (
                      <div key={offset} className="animate-fade-up">
                        <p className="mb-3 text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
                          Alternative {offset}
                        </p>
                        <div className="grid grid-cols-4 gap-2">
                          {alt.items.map((item) => (
                            <PhotoFrame
                              key={item.id}
                              path={item.photo_url}
                              alt={item.name || CATEGORY_LABELS[item.category]}
                              className="aspect-[3/4] rounded-sm"
                              fallbackLabel={CATEGORY_LABELS[item.category]}
                            />
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </section>

        <section>
          <h2 className="mb-4 font-display text-2xl">This week</h2>
          <div className="grid grid-cols-5 gap-3">
            {week.map((iso) => {
              const dayPlan = planFor(iso);
              const active = iso === selected;
              return (
                <button
                  key={iso}
                  onClick={() => setSelected(iso)}
                  className={`rounded-sm border p-2 text-left transition-colors ${
                    active ? "border-accent" : "border-border hover:border-foreground/30"
                  }`}
                >
                  <p className="text-[0.66rem] uppercase tracking-[0.18em] text-muted-foreground">
                    {shortDay(iso)}
                  </p>
                  <div className="mt-2 grid grid-cols-2 gap-1">
                    {dayPlan.items.slice(0, 4).map((item) => (
                      <PhotoFrame
                        key={item.id}
                        path={item.photo_url}
                        alt={item.name || CATEGORY_LABELS[item.category]}
                        className="aspect-square rounded-sm"
                        fallbackLabel="—"
                      />
                    ))}
                  </div>
                  <p className="mt-2 truncate text-[0.7rem] text-muted-foreground">
                    {dayPlan.eventLabel}
                  </p>
                </button>
              );
            })}
          </div>
        </section>

        <p className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
          <Lock className="mt-0.5 h-3 w-3 shrink-0" />
          Your closet photos and any reference photo stay private to your account. Reference photos
          are used only to generate your own try-on previews and are never shared publicly or with
          other users.
        </p>
      </div>
    </AppShell>
  );
}
